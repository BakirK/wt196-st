const request = require('supertest');
const express = require('express');

//const app = express();
const app = require('../index.js');

describe('GET /osoblje', function () {
    it('GET /osoblje vraca status 200', function (done) {
        request(app)
            .get('/osoblje')
            .expect(200, done);
    });
    it('GET /osoblje vraca 3 osobe', function (done) {
        request(app)
            .get('/osoblje')
            .end(function(err,res){
                if(err)done(err);
                var s=JSON.parse(res.text);
                if(s.length==3)
                done();
            });
    });
    
});
describe('Dohvatanje svih zauzeca',function(){
    /*before(function (done) {
        setTimeout(function(){
          done();
        }, 2000);
      });*/
    it('GET /ucitaj vraca status 200', function (done) {
        request(app)
            .get('/ucitaj')
            .expect(200, done);
    });
    it('GET /ucitaj vraca 1 periodicnu i 1 vandrednu rezevaciju', function (done) {
        request(app)
            .get('/ucitaj')
            .end(function(err,res){
                if(err)done(err);
                var s=JSON.parse(res.text);
                var s1=s.periodicna;
                var s2=s.vandredna;
                if(s1.length==1 && s2.length==1)
                done();
            });
    });
    it('dodavanjem nove periodicne rezervacije, azuriraju se rezervacije',  function (done) {
            //call the function we're testing
            var result = request(app).post('/upisiper?dan=5&sala=1-11&pocetak=13:00&kraj=14:30&mjesec=0&ime=Neko');

            //assertions
            result.then(function(data) {
                //expect(data).to.equal(blah);
                var s=JSON.parse(data.text);
                var s1=s.periodicna;
                var s2=s.vandredna;
                if(s1.length==2 && s2.length==1)
                done();
            }, function(error) {
            assert.fail(error);
            done();
        });
        
    });
    it('dodavanjem nove vandredne rezervacije, azuriraju se rezervacije',  function (done) {
        //call the function we're testing
        var result = request(app).post('/upisivan?datum=19&sala=1-11&pocetak=13:00&kraj=14:30&mjesec=0&ime=Neko');

        //assertions
        result.then(function(data) {
            //expect(data).to.equal(blah);
            var s=JSON.parse(data.text);
            var s1=s.periodicna;
            var s2=s.vandredna;
            if(s2.length==2)
            done();
        }, function(error) {
        assert.fail(error);
        done();
    });
    
});
});
describe('Dohvatanje svih sala',function(){
    it('GET /sala vraca status 200', function (done) {
        request(app)
            .get('/sala')
            .expect(200, done);
    });
    it('GET /sala vraca 2 sale', function (done) {
        request(app)
            .get('/sala')
            .end(function(err,res){
                if(err)done(err);
                var s=JSON.parse(res.text);
                if(s.length==2)
                done();
            });
    });
});
describe('Kreiranje nove rezervacije',function(){
    it('dodavanjem nove periodicne rezervacije, koja se preklapa sa vandrednom',  function (done) {
        //call the function we're testing
        var result = request(app).post('/upisiper?dan=3&sala=1-11&pocetak=12:00&kraj=13:00&mjesec=0&ime=Neko');

        //assertions
        result.then(function(data) {
            //expect(data).to.equal(blah);
            var s=JSON.parse(data.text);
            var s1=s.ime;
            var s2=s.prezime;
            if(s1&&s2)
            done();
        }, function(error) {
        assert.fail(error);
        done();
    });
    
});
it('pokusaj vandredne rezervacije, koja je vec rezervisana-vraca ime i prezime osobe koja je rezervisala',  function (done) {
    //call the function we're testing
    var result = request(app).post('/upisivan?datum=19&sala=1-11&pocetak=13:00&kraj=14:30&mjesec=0&ime=Neko');

    //assertions
    result.then(function(data) {
        //expect(data).to.equal(blah);
        var s=JSON.parse(data.text);
            var s1=s.ime;
            var s2=s.prezime;
            if(s1&&s2)
            done();
    }, function(error) {
    assert.fail(error);
    done();
});

});
});