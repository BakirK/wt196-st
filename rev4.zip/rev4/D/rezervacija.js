
window.onload=function(){
    Pozivi.prviCetvrta();
    Pozivi.prvi();
    Kalendar.tr_mjesec=new Date().getMonth();
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"),Kalendar.tr_mjesec);
    var op=document.getElementsByTagName("select")[0];
    Kalendar.ssala=op.options[op.selectedIndex].value;
    Kalendar.obojiZauzeca(document.getElementById("kalendar"),Kalendar.tr_mjesec,Kalendar.ssala,Kalendar.ppoc,Kalendar.pkraj);

}

//za dugme prethodni

var prr=document.getElementById("prethodni");

if(prr){
    prr.addEventListener("click", function(){
        //alert("kliknuto pr");
        if(Kalendar.tr_mjesec>0){
            Kalendar.tr_mjesec--;
        }
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"),Kalendar.tr_mjesec);
        if (typeof Kalendar.ppoc !== 'undefined' && typeof Kalendar.pkraj !== 'undefined' && typeof Kalendar.ssala !== 'undefined' && typeof Kalendar.tr_mjesec !== 'undefined'){
            Kalendar.obojiZauzeca(document.getElementById("kalendar"),Kalendar.tr_mjesec,Kalendar.ssala,Kalendar.ppoc,Kalendar.pkraj);
        }
    });
}

//za dugme sljedeci

var sljj=document.getElementById("sljedeci");
if(sljj){
    sljj.addEventListener("click", function(){
        if(Kalendar.tr_mjesec<11){
            Kalendar.tr_mjesec++;
        }
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"),Kalendar.tr_mjesec);
        if (typeof Kalendar.ppoc !== 'undefined' && typeof Kalendar.pkraj !== 'undefined' && typeof Kalendar.ssala !== 'undefined' && typeof Kalendar.tr_mjesec !== 'undefined'){
            Kalendar.obojiZauzeca(document.getElementById("kalendar"),Kalendar.tr_mjesec,Kalendar.ssala,Kalendar.ppoc,Kalendar.pkraj);
        }
    });
}

//promjena sale

var sall=document.getElementsByTagName("select")[0];
if(sall){
    sall.addEventListener("change",function(){
        var op=document.getElementsByTagName("select")[0];
        Kalendar.ssala=op.options[op.selectedIndex].value;
        if (typeof Kalendar.ppoc !== 'undefined' && typeof Kalendar.pkraj !== 'undefined' && typeof Kalendar.ssala !== 'undefined' && typeof Kalendar.tr_mjesec !== 'undefined'){
            Kalendar.obojiZauzeca(document.getElementById("kalendar"),Kalendar.tr_mjesec,Kalendar.ssala,Kalendar.ppoc,Kalendar.pkraj);
        }
    });
}

//promjena pocetka

var poo=document.getElementsByName("pocetak")[0];
if(poo){
    poo.addEventListener("change",function(){
        Kalendar.ppoc=document.getElementsByName("pocetak")[0].value;
        if (typeof Kalendar.ppoc !== 'undefined' && typeof Kalendar.pkraj !== 'undefined' && typeof Kalendar.ssala !== 'undefined' && typeof Kalendar.tr_mjesec !== 'undefined'){
            Kalendar.obojiZauzeca(document.getElementById("kalendar"),Kalendar.tr_mjesec,Kalendar.ssala,Kalendar.ppoc,Kalendar.pkraj);
        }
    });
}

//promjena kraja

var krr=document.getElementsByName("kraj")[0];
if(krr){
    krr.addEventListener("change",function(){
        Kalendar.pkraj=document.getElementsByName("kraj")[0].value;
        if (typeof Kalendar.ppoc !== 'undefined' && typeof Kalendar.pkraj !== 'undefined' && typeof Kalendar.ssala !== 'undefined' && typeof Kalendar.tr_mjesec !== 'undefined'){
            Kalendar.obojiZauzeca(document.getElementById("kalendar"),Kalendar.tr_mjesec,Kalendar.ssala,Kalendar.ppoc,Kalendar.pkraj);
        }
    });
}