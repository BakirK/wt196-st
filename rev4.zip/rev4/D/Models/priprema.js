const db = require('./db.js')
db.sequelize.sync({force:true}).then(function(){
    inicializacija().then(function(){
        console.log("Gotovo kreiranje tabela i ubacivanje pocetnih podataka!");
        //process.exit();
    });
});
function inicializacija(){
    var autor1,autor2;
    var osobljeListaPromisea=[];
    var salaListaPromisea=[];
    var terminListaPromisea=[];
    var rezervacijeListaPromisea=[];
    return new Promise(function(resolve,reject){
    osobljeListaPromisea.push(db.osoblje.create({ime:'Neko',prezime:'Nekić',uloga:'profesor'}));
    osobljeListaPromisea.push(db.osoblje.create({ime:'Drugi',prezime:'Neko',uloga:'asistent'}));
    osobljeListaPromisea.push(db.osoblje.create({ime:'Test',prezime:'Test',uloga:'asistent'}));
    Promise.all(osobljeListaPromisea).then(function(osoblje){
        var neko = osoblje.filter(function(a){return a.ime==='Neko'})[0];
        //console.log(neko);
        var drugi=osoblje.filter(function(a){return a.ime==='Drugi'})[0];
        var test=osoblje.filter(function(a){return a.ime==='Test'})[0];

        salaListaPromisea.push(
            db.sala.create({naziv:'1-11',zaduzenaOsoba:neko.id})
        );

        salaListaPromisea.push(
            db.sala.create({naziv:'1-15',zaduzenaOsoba:drugi.id})
        );
        

        Promise.all(salaListaPromisea).then(function(sale){
            var s1=sale.filter(function(a){return a.id===1})[0];

            terminListaPromisea.push(db.termin.create({redovni:false,datum:'01.01.2020',pocetak:'12:00',kraj:'13:00'}));
            terminListaPromisea.push(db.termin.create({redovni:true,dan:0,semestar:'zimski',pocetak:'13:00',kraj:'14:00'}));

            Promise.all(terminListaPromisea).then(function(termini){
                var t1=termini.filter(function(a){return a.id===1})[0];
                var t2=termini.filter(function(a){return a.id===2})[0];

                

                rezervacijeListaPromisea.push(
                    db.rezervacija.create({termin:t1.id,sala:s1.id,osoba:neko.id})
                );

                rezervacijeListaPromisea.push(
                    db.rezervacija.create({termin:t2.id,sala:s1.id,osoba:test.id})
                );

                Promise.all(rezervacijeListaPromisea).catch(function(err){console.log("Rezervacije greska "+err)});
            }).catch(function(err){console.log("Termin greska "+err)});
        }).catch(function(err){console.log("Sala greska "+err);});
    }).catch(function(err){console.log("Osoblje greska "+err);});
    });
}
