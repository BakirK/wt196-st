const Sequelize = require("sequelize");
const sequelize = new Sequelize("DBWT19","root","root",{host:"127.0.0.1",dialect:"mysql",logging:false});

const db={};


db.Sequelize = Sequelize;  
db.sequelize = sequelize;

//import modela
db.osoblje = sequelize.import(__dirname+'/osoblje.js');
db.termin = sequelize.import(__dirname+'/termin.js');
db.sala = sequelize.import(__dirname+'/sala.js');
db.rezervacija = sequelize.import(__dirname+'/rezervacija.js');

//relacije
// Veza 1-n vise knjiga se moze nalaziti u biblioteci
db.osoblje.hasMany(db.rezervacija,{as:'osoba',foreignKey:'osoba'});

db.termin.hasOne(db.rezervacija,{foreignKey: 'termin' ,as:'termin',unique:true});

db.sala.hasMany(db.rezervacija,{as:'sala',foreignKey:'sala'});

db.osoblje.hasOne(db.sala,{as:'zaduziOsobu',foreignKey:'zaduzenaOsoba'});

// Veza n-m autor moze imati vise knjiga, a knjiga vise autora
//db.autorKnjiga=db.knjiga.belongsToMany(db.autor,{as:'autori',through:'autor_knjiga',foreignKey:'knjigaId'});
//db.autor.belongsToMany(db.knjiga,{as:'knjige',through:'autor_knjiga',foreignKey:'autorId'});


module.exports=db;