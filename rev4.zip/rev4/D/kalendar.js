
let Kalendar = (function(){
    //
    //ovdje idu privatni atributi
    

    var niz_periodicnih=[];
    var niz_vanrednih=[];
    var tr_mjesec;

    var ssala;
    var ppoc;
    var pkraj;

    var op=document.getElementsByTagName("select")[0];

    var mmm=['Januar','Februar','Mart','April','Maj','Juni','Juli','Avgust','Septembar','Oktobar','Novembar','Decembar'];

    

    //
    function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj){
    //implementacija ide ovdje
    var datumi=kalendarRef.getElementsByClassName("datum");
    var duzina=datumi.length;
    var date=new Date();
    var firstDay =  new Date(date.getFullYear(), mjesec, 1); 
    var s=firstDay.getDay();
    var lastDay = new Date(date.getFullYear(), mjesec + 1, 0);
    var l=lastDay.getDate();
    if(s===0){
        s=6;
    }
    for(var i=0;i<duzina;i++){
        if(s===6){
            s=7;
        }
        if(i>=s-1){
            datumi[i].lastElementChild.className= "slobodna";
        }
    }
    niz_periodicnih.forEach(element =>{
        var s_poc=element.pocetak;
        var s_kraj=element.kraj;
        var str_poc=s_poc.split(":");
        var str_kraj=s_kraj.split(":");
        var poc_sat=+str_poc[0];
        var poc_min=+str_poc[1];
        var kraj_sat=+str_kraj[0];
        var kraj_min=+str_kraj[1];

        var str_p_poc=pocetak.split(":");
        var p_poc_sat=+str_p_poc[0];
        var p_poc_min=+str_p_poc[1];

        var str_p_kraj=kraj.split(":");
        var p_kraj_sat=+str_p_kraj[0];
        var p_kraj_min=+str_p_kraj[1];
        if(  (  (element.semestar.toString()==="zimski" && (mjesec>8 || mjesec===0 ))  || ((element.semestar.toString()==="ljetni" && (mjesec>0 && mjesec<6 ))) )&& sala.toString()===element.naziv && 
        ((pocetak===element.pocetak && kraj===element.kraj) 
        || (( (p_poc_sat>poc_sat) || (p_poc_sat==poc_sat && p_poc_min>=poc_min)) && (  (p_poc_sat<kraj_sat) || (p_poc_sat==kraj_sat && p_poc_min<kraj_min)) )
        || (((p_kraj_sat<kraj_sat ) || (p_kraj_sat==kraj_sat && p_kraj_min<kraj_min)) && ((p_kraj_sat>poc_sat) || (p_kraj_sat==poc_sat && p_kraj_min>poc_min))      )
        || (((p_poc_sat<poc_sat) || (p_poc_sat==poc_sat && p_poc_min<=poc_min)) && ((p_kraj_sat>kraj_sat ) || (p_kraj_sat==kraj_sat && p_kraj_min>=kraj_min)))
        )
        ){
            for(var i=0;i<duzina;i++){
                var x = datumi[i].innerText;
                if(i>=s-1 && element.dan === (i)%7){
                    datumi[i].lastElementChild.className= "zauzeta";
                }     
            }
        }
    });


    niz_vanrednih.forEach(element =>{

        var dateString = element.datum; // Oct 23

        var dateParts = dateString.split(".");

        var dateObject = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]); 

        var god=+dateParts[2];
        var mjesecc=dateParts[1] - 1;
        var dann=+dateParts[0];

        var s_poc=element.pocetak;
        var s_kraj=element.kraj;
        var str_poc=s_poc.split(":");
        var str_kraj=s_kraj.split(":");
        var poc_sat=+str_poc[0];
        var poc_min=+str_poc[1];
        var kraj_sat=+str_kraj[0];
        var kraj_min=+str_kraj[1];
        
        var str_p_poc=pocetak.split(":");
        var p_poc_sat=+str_p_poc[0];
        var p_poc_min=+str_p_poc[1];

        var str_p_kraj=kraj.split(":");
        var p_kraj_sat=+str_p_kraj[0];
        var p_kraj_min=+str_p_kraj[1];

        if(mjesecc===Kalendar.tr_mjesec && sala.toString()===element.naziv && 
        ((pocetak===element.pocetak && kraj===element.kraj) 
        || (( (p_poc_sat>poc_sat) || (p_poc_sat==poc_sat && p_poc_min>=poc_min)) && (  (p_poc_sat<kraj_sat) || (p_poc_sat==kraj_sat && p_poc_min<kraj_min)) )
        || (((p_kraj_sat<kraj_sat ) || (p_kraj_sat==kraj_sat && p_kraj_min<kraj_min)) && ((p_kraj_sat>poc_sat) || (p_kraj_sat==poc_sat && p_kraj_min>poc_min))      )
        || (((p_poc_sat<poc_sat) || (p_poc_sat==poc_sat && p_poc_min<=poc_min)) && ((p_kraj_sat>kraj_sat ) || (p_kraj_sat==kraj_sat && p_kraj_min>=kraj_min)))
        )
        ){
            for(var i=0;i<duzina;i++){
                var x = datumi[i].innerText;
                if(s===6){
                    s=7;
                }
                if(i>=s-1 && dann === (i+1)-s+1){
                    datumi[i].lastElementChild.className= "zauzeta";
                }
            }
        }
    });
    }
    function ucitajPodatkeImpl(periodicna, vanredna){
    //implementacija ide ovdje
    niz_periodicnih=periodicna;
    niz_vanrednih=vanredna;
    
    }
    function iscrtajKalendarImpl(kalendarRef, mjesec){
    //implementacija ide ovdje
    var mm=kalendarRef.getElementsByTagName("h3")[0];
    if(mm){
        mm.innerHTML=mmm[Kalendar.tr_mjesec];
    }
    var d=document.getElementsByClassName("datumi")[0];
            while(d.firstChild){
                d.removeChild(d.firstChild);
            }
    var date=new Date();
    var firstDay =  new Date(date.getFullYear(), mjesec, 1); 
    var s=firstDay.getDay();
    if(s===0){
        s=7;
    }
    var lastDay = new Date(date.getFullYear(), mjesec + 1, 0);
    var l=lastDay.getDate();
    for(var i=0;i<s-1;i++){
        let div = document.createElement('div');
        div.className = "datum";
        div.innerHTML = "&nbsp;";
        document.getElementsByClassName("datumi")[0].appendChild(div);
    }
    for(i=0;i<l;i++){
        let divd = document.createElement('div');
        divd.className = "datum";
        
        let divb = document.createElement('div');
        divb.className = "broj";
        let tb=document.createElement('p');
        tb.innerHTML=(i+1).toString();
        let sl=document.createElement('div');
        sl.className="slobodna";
        divb.appendChild(tb);
        divd.appendChild(divb);
        divd.appendChild(sl);
        document.getElementsByClassName("datumi")[0].appendChild(divd);
        divd.onclick = function(){
            var dat=tb.textContent;
            var klasa=sl.className;
            if(klasa=="slobodna"){
                var per_check=document.getElementById("periodicna").checked;
                if((per_check==true && (Kalendar.tr_mjesec<6 || Kalendar.tr_mjesec>9)) || per_check==false){
                var poruka=confirm("Da li želite da rezervišete ovaj termin");
                if(poruka==true){
                    
                        Pozivi.drugi(dat);
                    
                }
            }

            }
            
            
        }
    }
    }
    return {
    obojiZauzeca: obojiZauzecaImpl,
    ucitajPodatke: ucitajPodatkeImpl,
    iscrtajKalendar: iscrtajKalendarImpl
    }
}());
//primjer korištenja modula
//Kalendar.obojiZauzeca(document.getElementById(“kalendar”),1,”1-15”,”12:00”,”13:30”);
    