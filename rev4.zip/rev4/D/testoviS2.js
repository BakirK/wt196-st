let assert = chai.assert;
describe('Kalendar', function() {
  document.getElementById("kalendar").style.display = 'none';
 describe('obojiZauzeca()', function() {
   it('Pozivanje obojiZauzeca kada podaci nisu učitani: očekivana vrijednost da se ne oboji niti jedan dan   ', function() {
    Kalendar.obojiZauzeca(document.getElementById("kalendar"),1,"1-15","12:00","13:30");   
      let datumi=document.getElementsByClassName("zauzeta");
      let br_z = datumi.length;
      assert.equal(br_z, 0,"Broj zauzetih treba biti 0");
   });
   it('Pozivanje obojiZauzeca gdje u zauzećima postoje duple vrijednosti za zauzeće istog termina: očekivano je da se dan oboji bez obzira što postoje duple vrijednosti', function() {
       var z1={
        dan: 0,
        semestar: "zimski",
        pocetak: "12:00",
        kraj: "13:30",
        naziv: "0-03",
        predavac: "patak"
       };
       var z2={
        dan: 0,
        semestar: "zimski",
        pocetak: "12:00",
        kraj: "13:30",
        naziv: "0-03",
        predavac: "patak"
       };
       var niz_zauzeca=[z1,z2];
       var niz_van=[];
       Kalendar.ucitajPodatke(niz_zauzeca,niz_van);
       Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-03","12:00","13:30"); 
       let datumi=document.getElementsByClassName("zauzeta");
       let br_z = datumi.length;
       assert.equal(br_z, 4,"Broj zauzetih treba biti 4 jer su periodični podatci u pitanju");
     });
     it('Pozivanje obojiZauzece kada u podacima postoji periodično zauzeće za drugi semestar: očekivano je da se ne oboji zauzeće', function() {
      var z1={
       dan: 0,
       semestar: "ljetni",
       pocetak: "12:00",
       kraj: "13:30",
       naziv: "0-03",
       predavac: "patak"
      };
      var z2={
       dan: 3,
       semestar: "ljetni",
       pocetak: "12:00",
       kraj: "13:30",
       naziv: "0-03",
       predavac: "patak"
      };
      var niz_zauzeca=[z1,z2];
      var niz_van=[];
      Kalendar.ucitajPodatke(niz_zauzeca,niz_van);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-03","12:00","13:30"); 
      let datumi=document.getElementsByClassName("zauzeta");
      let br_z = datumi.length;
      assert.equal(br_z, 0,"Broj zauzetih treba biti 0 jer su podatci za ljetni semestar, a prikazuje se Novembar");
    });
    it('Pozivanje obojiZauzece kada u podacima postoji zauzeće termina ali u drugom mjesecu: očekivano je da se ne oboji zauzeće', function() {
      var z1={
       datum: '12.12.2019',
       pocetak: "12:00",
       kraj: "13:30",
       naziv: "0-03",
       predavac: "patak"
      };
      var z2={
       datum: '11.12.2019',
       pocetak: "12:00",
       kraj: "13:30",
       naziv: "0-03",
       predavac: "patak"
      };
      var niz_zauzeca_van=[z1,z2];
      var niz_per=[];
      Kalendar.ucitajPodatke(niz_per,niz_zauzeca_van);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-03","12:00","13:30"); 
      let datumi=document.getElementsByClassName("zauzeta");
      let br_z = datumi.length;
      assert.equal(br_z, 0,"Broj zauzetih treba biti 0 jer su podatci iz drugog mjeseca");
    });
    it('Pozivanje obojiZauzece kada su u podacima svi termini u mjesecu zauzeti: očekivano je da se svi dani oboje', function() {
      var z1={
       dan: 0,
       semestar: "zimski",
       pocetak: "12:00",
       kraj: "13:30",
       naziv: "0-03",
       predavac: "patak"
      };
      var z2={
        dan: 1,
        semestar: "zimski",
        pocetak: "12:00",
        kraj: "13:30",
        naziv: "0-03",
        predavac: "patak"
       };
      var z3={
       dan: 2,
       semestar: "zimski",
       pocetak: "12:00",
       kraj: "13:30",
       naziv: "0-03",
       predavac: "patak"
      };
      var z4={
        dan: 3,
        semestar: "zimski",
        pocetak: "12:00",
        kraj: "13:30",
        naziv: "0-03",
        predavac: "patak"
       };
       var z5={
        dan: 4,
        semestar: "zimski",
        pocetak: "12:00",
        kraj: "13:30",
        naziv: "0-03",
        predavac: "patak"
       };
       var z6={
        dan: 5,
        semestar: "zimski",
        pocetak: "12:00",
        kraj: "13:30",
        naziv: "0-03",
        predavac: "patak"
       };
       var z7={
        dan: 6,
        semestar: "zimski",
        pocetak: "12:00",
        kraj: "13:30",
        naziv: "0-03",
        predavac: "patak"
       };
      var niz_zauzeca=[z1,z2,z3,z4,z5,z6,z7];
      var niz_van=[];
      Kalendar.ucitajPodatke(niz_zauzeca,niz_van);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-03","12:00","13:30"); 
      let datumi=document.getElementsByClassName("zauzeta");
      let br_z = datumi.length;
      assert.equal(br_z, 30,"Broj zauzetih treba biti 30, tj svi dani u mjesecu");
    });
    it('Dva puta uzastopno pozivanje obojiZauzece: očekivano je da boja zauzeća ostane ista', function() {
      var z1={
       dan: 0,
       semestar: "zimski",
       pocetak: "12:00",
       kraj: "13:30",
       naziv: "0-03",
       predavac: "patak"
      };
       var z3={
        datum: '10.11.2019',
        pocetak: "12:00",
        kraj: "13:30",
        naziv: "0-03",
        predavac: "patak"
       };
      var niz_zauzeca=[z1];
      var niz_van=[z3];
      Kalendar.ucitajPodatke(niz_zauzeca,niz_van);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-03","12:00","13:30"); 
      Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-03","12:00","13:30");
      let datumi=document.getElementsByClassName("zauzeta");
      let br_z = datumi.length;
      assert.equal(br_z, 5,"Broj zauzetih treba biti 5, 4 za periodicno i 1 za vandredna, bez obzira na 2 poziva obojiZauzeca()");
    });
    it('Pozivanje ucitajPodatke, obojiZauzeca, ucitajPodatke - drugi podaci, obojiZauzeca: očekivano da se zauzeća iz prvih podataka ne ostanu obojena, tj. primjenjuju se samo posljednje učitani podac', function() {
      var z1={
       dan: 0,
       semestar: "zimski",
       pocetak: "12:00",
       kraj: "13:30",
       naziv: "0-03",
       predavac: "patak"
      };
      var niz_zauzeca=[z1];
      var niz_van=[];
      Kalendar.ucitajPodatke(niz_zauzeca,niz_van);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-03","12:00","13:30"); 
      let datumi=document.getElementsByClassName("zauzeta");
      let br_z = datumi.length;
      var z2={
        datum: '12.11.2019',
        pocetak: "12:00",
        kraj: "13:30",
        naziv: "0-03",
        predavac: "patak"
       };
       var z3={
        datum: '10.11.2019',
        pocetak: "12:00",
        kraj: "13:30",
        naziv: "0-03",
        predavac: "patak"
       };
      niz_zauzeca=[]
       niz_van=[z2,z3];
       Kalendar.ucitajPodatke(niz_zauzeca,niz_van);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-03","12:00","13:30");
      datumi=document.getElementsByClassName("zauzeta")
      br_z = datumi.length;
      assert.equal(br_z, 2,"Broj zauzetih treba biti 6, 4 za periodicno i 2 vandredna, bez obzira na 2 poziva obojiZauzeca()");
    });
    it('Pozivanje obojiZauzeca(), gdje se preklapa vandredni i periodicni, treba ostati obojeno', function() {
      var z1={
       dan: 0,
       semestar: "zimski",
       pocetak: "12:00",
       kraj: "13:30",
       naziv: "0-03",
       predavac: "patak"
      };
      var z2={
        datum: '11.11.2019',
        pocetak: "12:00",
        kraj: "13:30",
        naziv: "0-03",
        predavac: "patak"
       };
       var z3={
        datum: '10.11.2019',
        pocetak: "12:00",
        kraj: "13:30",
        naziv: "0-03",
        predavac: "patak"
       };
      var niz_zauzeca=[z1];
      var niz_van=[z2,z3];
      Kalendar.ucitajPodatke(niz_zauzeca,niz_van);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-03","12:00","13:30"); 
      let datumi=document.getElementsByClassName("zauzeta");
      let br_z = datumi.length;
      assert.equal(br_z, 5,"Broj zauzetih treba biti 5, 4 za periodicno i 2 za vandredna ali se jedan preklapa, bez obzira na 2 poziva obojiZauzeca()");
    });
    it('Pozivanje obojiZauzeca(), gdje se šalje neki nemoguci datum', function() {
      var z1={
        datum: '33.11.2019',
        pocetak: "12:00",
        kraj: "13:30",
        naziv: "0-03",
        predavac: "patak"
       };
      var niz_zauzeca=[];
      var niz_van=[z1];
      Kalendar.ucitajPodatke(niz_zauzeca,niz_van);
      Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-03","12:00","13:30"); 
      let datumi=document.getElementsByClassName("zauzeta");
      let br_z = datumi.length;
      assert.equal(br_z, 0,"Broj zauzetih treba biti 0, jer je datum nemoguc");
    });
 });
 describe('iscrtajKalendar()', function() {
  it('Pozivanje iscrtajKalendar za mjesec sa 30 dana: očekivano je da se prikaže 30 dana', function() {
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"),10);   
      let datumi=document.getElementsByClassName("broj");
      let br_z = datumi.length;
      assert.equal(br_z, 30,"Broj dana treba biti 30");
   });
   it('Pozivanje iscrtajKalendar za mjesec sa 31 dan: očekivano je da se prikaže 31 dan', function() {
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"),11);   
      let datumi=document.getElementsByClassName("broj");
      let br_z = datumi.length;
      assert.equal(br_z, 31,"Broj dana treba biti 31");
   });
   it('Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 1. dan u petak', function() {
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"),10);   
      let datumi=document.getElementsByClassName("broj");
      let datumi_uk=document.getElementsByClassName("datum");
      let br_z = datumi.length;
      let br_dat_uk=datumi_uk.length;
      let prvi_dan=br_dat_uk-br_z;
      assert.equal(prvi_dan, 4,"Prvi dan treba imati index 4 tj petak");
   });
   it('Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 30. dan u subotu', function() {
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"),10);   
      let datumi=document.getElementsByClassName("broj");
      let datumi_uk=document.getElementsByClassName("datum");
      let br_z = datumi.length;
      let br_dat_uk = datumi_uk.length;
      let zadnji_dan=br_dat_uk%7;
      assert.equal(zadnji_dan, 6,"Zadnji dan treba imati index 6 tj subota");
   });
   it('Pozivanje iscrtajKalendar za januar: očekivano je da brojevi dana idu od 1 do 31 počevši od utorka', function() {
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"),0);   
    let datumi=document.getElementsByClassName("broj");
    let datumi_uk=document.getElementsByClassName("datum");
    let br_z = datumi.length;
    let br_dat_uk=datumi_uk.length;
    let prvi_dan=br_dat_uk-br_z;
      assert.equal(prvi_dan, 1,"Prvi dan treba imati index 1 jer počinje u utorak");
   });
   it('Pozivanje iscrtajKalendar za Februar: očekivano je da je se prikaže 28 dana', function() {
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"),1);   
      let datumi=document.getElementsByClassName("broj");
      let br_z = datumi.length;
      assert.equal(br_z, 28,"Broj dana treba biti 28");
   });
   it('Pozivanje iscrtajKalendar dva puta uzastopno za isti mjesec: očekivano je da se ispravno pozove', function() {
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"),10);   
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"),10); 
      let datumi=document.getElementsByClassName("broj");
      let br_z = datumi.length;
      assert.equal(br_z, 30,"Broj dana treba biti 30, iako se funkcija dva puta pozvala");
   });
 });
});