window.onload=function(){
    Pozivi.treci();
}