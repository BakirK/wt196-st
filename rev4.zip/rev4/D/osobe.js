window.onload=function(){
    Pozivi.treciCetvrta();
    var dat=new this.Date();
    this.console.log(dat);
    this.console.log(dat.getHours());
    var intervalID = setInterval(function(){Pozivi.treciCetvrta()}, 30000);
}