const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const db = require('./Models/db.js');
//const aa = require('./Models/priprema.js');

const app = express();
app.use(bodyParser.json());

app.use(express.static(__dirname));

app.get('/rezervacija.html',function(req,res){
    res.sendFile(__dirname+"/rezervacija.html");
});
app.get('/ucitaj',function(req,res){
    //res.sendFile(__dirname+"/zauzeca.json");
    db.rezervacija.findAll().then(function(or){
        var per=[];
        var van=[];
        var idemo=or.length;
        //console.log("id "+idemo);
        for(var i=0;i<or.length;i++){
            let ter=or[i].termin;
            let sal=or[i].sala; 
            let oso=or[i].osoba
            console.log(ter+" "+sal+" "+oso);
            let termin_n;
            let osoba_n;
            let sala_n;
            db.termin.findOne({where:{id:ter}}).then(function(ot){
                //console.log("sss "+ot.length);
                termin_n=ot;
                db.sala.findOne({where:{id:sal}}).then(function(os){
                    console.log(os.naziv);
                    sala_n=os;
                    db.osoblje.findOne({where:{id:oso}}).then(function(oo){
                        //console.log("ocaj "+termin_n.redovni);
                        osoba_n=oo;
                        if(termin_n.redovni==true){
                            var obj={"dan":termin_n.dan,"semestar":termin_n.semestar,"pocetak":termin_n.pocetak,"kraj":termin_n.kraj,"naziv":sala_n.naziv,"predavac":osoba_n.ime};
                            //console.log(obj);
                            per.push(obj);
                        }
                        else{
                            var ob2={"datum":termin_n.datum,"pocetak":termin_n.pocetak,"kraj":termin_n.kraj,"naziv":sala_n.naziv,"predavac":osoba_n.ime};
                            //console.log(ob2);
                            van.push(ob2);
                        }
                        if(per.length+van.length===idemo){
                            //console.log("kraj "+per.length+" "+van.length);
                            //console.log(per);
                            //console.log(van);
        
                            var ob_per={"periodicna":per,"vandredna":van};
                            //console.log(ob_per);
                            res.send(ob_per);
                        }
                        
                    });
                });

            });
            
            
        }
        //console.log(per);
    });
});
app.get('/',function(req,res){
    res.sendFile(__dirname+"/pocetna.html");
});
app.post('/upisiper',function(req,res){



        console.log(req.query.dan+" "+req.query.pocetak+" "+req.query.kraj);


        var mjs=req.query.mjesec;
        var sem;

        if((mjs>8 && mjs<12) || mjs==0){
            sem="zimski";
        }
        else if(mjs>0 && mjs<6){
            sem="ljetni";
        }

        db.sala.findOne({where:{naziv:req.query.sala}}).then(function(os){
            bsala=os;
            //console.log(os.length);
            //console.log(os);
            //res.send(JSON.stringify(os));

            db.osoblje.findOne({where:{ime:req.query.ime}}).then(function(oo){
                //console.log(oo);
                
                //dan:req.query.dan,
                db.termin.findOne({where:{dan:req.query.dan,pocetak:req.query.pocetak,kraj:req.query.kraj}}).then(function(ot){
                    console.log(ot);
                    if(ot===null){


                        var mjs=req.query.mjesec;
                        var greska=false;
                        var sun=false;
                        db.termin.findAll({where:{redovni:false}}).then(function(tt){
                            console.log("duzina hankeprca "+tt.length);
                            
                            for(var i=0;i<tt.length;i++){
                                console.log(tt[i].datum+"1");
                                if((mjs>8 && mjs<12) || mjs==0){
                    
                                    var dateString = tt[i].datum; // Oct 23
                                    console.log(dateString);
                
                                    var dateParts = dateString.split(".");
                
                                    var dateObject = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]);
                                    
                                    
                
                                    var god=+dateParts[2];
                                    var mjesecc=dateParts[1] - 1;
                                    var dann=+dateParts[0];
                                    console.log("dan "+dann+" mjesec "+mjesecc);
                                    //ako je mjesec van zimskog semestra
                                    if(mjesecc>0 && mjesecc<9)continue;
                
                                    var firstDay =  new Date(dateObject.getFullYear(), mjesecc, 1); 
                                    console.log("dar "+firstDay);
                                    var s=firstDay.getDay();
                                    console.log("ss "+s);
                
                                    var dd;
                                    if(s===0){
                                        s=6;
                                        dd=(s-1)+parseInt(dann);
                                    }else{
                                        dd=(s-2)+parseInt(dann);
                                    }
                    
                                    dd=dd%7;
                                    console.log("dd "+dd+" d "+req.query.dan);
                                    //ispravka treba && tt[i].naziv==req.query.sala
                                    let ssala;

                                    let s_poc=tt[i].pocetak;
                                    let s_kraj=tt[i].kraj;
                                    let str_poc=s_poc.split(":");
                                    let str_kraj=s_kraj.split(":");
                                    let poc_sat=+str_poc[0];
                                    let poc_min=+str_poc[1];
                                    let kraj_sat=+str_kraj[0];
                                    let kraj_min=+str_kraj[1];

                                    let str_p_poc=req.query.pocetak.split(":");
                                    let p_poc_sat=+str_p_poc[0];
                                    let p_poc_min=+str_p_poc[1];

                                    let str_p_kraj=req.query.kraj.split(":");
                                    let p_kraj_sat=+str_p_kraj[0];
                                    let p_kraj_min=+str_p_kraj[1];

                                    let p=tt[i].pocetak;
                                    let k=tt[i].kraj;

                                    let muse=tt[i].id;
                                    db.rezervacija.findOne({where:{termin:tt[i].id}}).then(function(oor){


                                        ssala=oor.sala;
                                        


                                        db.sala.findOne({where:{id:oor.sala}}).then(function(sss){
                                            console.log("sasad "+sss.naziv+" "+req.query.sala);

                                            let me = new String(req.query.sala);
                                            let you = new String(sss.naziv);
                                            let isEquel = JSON.stringify(me) === JSON.stringify(you);
                                            console.log("zadnje "+isEquel);
                                            if(dd==parseInt(req.query.dan ) && isEquel==true && ((req.query.pocetak===p && req.query.kraj===k) 
                                    || (( (p_poc_sat>poc_sat) || (p_poc_sat==poc_sat && p_poc_min>=poc_min)) && (  (p_poc_sat<kraj_sat) || (p_poc_sat==kraj_sat && p_poc_min<kraj_min)) )
                                    || (((p_kraj_sat<kraj_sat ) || (p_kraj_sat==kraj_sat && p_kraj_min<kraj_min)) && ((p_kraj_sat>poc_sat) || (p_kraj_sat==poc_sat && p_kraj_min>poc_min))      )
                                    || (((p_poc_sat<poc_sat) || (p_poc_sat==poc_sat && p_poc_min<=poc_min)) && ((p_kraj_sat>kraj_sat ) || (p_kraj_sat==kraj_sat && p_kraj_min>=kraj_min)))
                                    )){
                                        
                                        greska=true;
                                        console.log("isao u gr");
                                        var c=toString(req.query.sala);
                                        console.log("tip " + typeof sss.naziv+" tip 2 "+ typeof req.query.sala+" tip3 "+typeof c);
                                        console.log(sss.naziv.length+" "+req.query.sala.length);
                                        var s=toString(sss.naziv);
                                        var n = c.localeCompare(s);
                                        console.log("da vidim "+n);

                                        
                                        
                                        
                                        //greska=false;
                                        
                                        //break;
                                    }
                                    if(greska==false ){
                                        console.log("ne treba");
                                        
                                        db.termin.create({redovni:true,dan:req.query.dan,semestar:sem,pocetak:req.query.pocetak,kraj:req.query.kraj}).then(function(){
                                            db.termin.findOne({where:{dan:req.query.dan,pocetak:req.query.pocetak,kraj:req.query.kraj}}).then(function(ot2){
                                                //Promise.all(ot2);
                                                //console.log(ot2.di+" "+os.id+" "+oo.id);
                                                //console.log("ter");
                                                console.log(os);
                                                db.rezervacija.create({termin:ot2.id,sala:os.id,osoba:oo.id}).then(function(){
                                                    db.rezervacija.findAll().then(function(or){
                                                        var per=[];
                                                        var van=[];
                                                        var idemo=or.length;
                                                        //console.log("id "+idemo);
                                                        for(var i=0;i<or.length;i++){
                                                            let ter=or[i].termin;
                                                            let sal=or[i].sala; 
                                                            let oso=or[i].osoba
                                                            console.log(ter+" "+sal+" "+oso);
                                                            let termin_n;
                                                            let osoba_n;
                                                            let sala_n;
                                                            db.termin.findOne({where:{id:ter}}).then(function(ot){
                                                                //console.log("sss "+ot.length);
                                                                termin_n=ot;
                                                                db.sala.findOne({where:{id:sal}}).then(function(os){
                                                                    //console.log(os.naziv);
                                                                    sala_n=os;
                                                                    db.osoblje.findOne({where:{id:oso}}).then(function(oo){
                                                                        //console.log("ocaj "+termin_n.redovni);
                                                                        osoba_n=oo;
                                                                        if(termin_n.redovni==true){
                                                                            console.log("per");
                                                                            var obj={"dan":termin_n.dan,"semestar":termin_n.semestar,"pocetak":termin_n.pocetak,"kraj":termin_n.kraj,"naziv":sala_n.naziv,"predavac":osoba_n.ime};
                                                                            //console.log(obj);
                                                                            per.push(obj);
                                                                        }
                                                                        else{
                                                                            var ob2={"datum":termin_n.datum,"pocetak":termin_n.pocetak,"kraj":termin_n.kraj,"naziv":sala_n.naziv,"predavac":osoba_n.ime};
                                                                            //console.log(ob2);
                                                                            van.push(ob2);
                                                                        }
                                                                        if(per.length+van.length===idemo){
                                                                            //console.log("kraj "+per.length+" "+van.length);
                                                                            //console.log(per);
                                                                            //console.log(van);
                                                        
                                                                            var ob_per={"periodicna":per,"vandredna":van};
                                                                            console.log(ob_per);
                                                                            //res.status(201);
                                                                            res.send(JSON.stringify( ob_per));
                                                                            //return ob_per;
                                                                        }
                                                                        
                                                                    });
                                                                });
                                                
                                                            });
                                                            
                                                            
                                                        }
                                                        //console.log(per);
                                                    });
                                                });
                                            });
                                        });
                                    }
                                    else{
                                        console.log("ovdjeee");
                                        //console.log("ids osobe "+tt[i].id);
                                        db.rezervacija.findOne({where:{termin:muse}}).then(function(orr){
                                            db.osoblje.findOne({where:{id:orr.osoba}}).then(function(ooo){
                                                res.send({"ime":ooo.ime,"prezime":ooo.prezime});
                                            });
                                        });
                                        
                                    }


                                    
                                        });
                                        

                                    });

                                    
                                    
                                    //&& ssala!==req.query.naziv
                                    
                                }
                                else if(mjs>0 && mjs<6){
                    
                                    var dateString = tt[i].datum; // Oct 23
                
                                    var dateParts = dateString.split(".");
                
                                    var dateObject = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]); 
                
                                    var god=+dateParts[2];
                                    var mjesecc=dateParts[1] - 1;
                                    var dann=+dateParts[0];
                
                                    //ako je mjesec van ljetnog semestra
                                    if((mjesecc>8 && mjesecc<12) || mjesecc==0)continue;
                                    var firstDay =  new Date(dateObject.getFullYear(), mjesecc, 1); 
                                    var s=firstDay.getDay();
                
                                    var dd;
                                    if(s===0){
                                        s=6;
                                        dd=(s-1)+parseInt(dann);
                                    }else{
                                        dd=(s-2)+parseInt(dann);
                                    }
                    
                                    dd=dd%7;
                                    if(dd==parseInt(req.query.dan)){
                                        greska=true;
                                    }
                                    
                                    /*if(dd==parseInt(req.query.dan)){
                                        greska=true;
                                    }*/
                                }


                                

                            }
                            
                            
                            /*if(greska==false ){
                                console.log("ne treba");
                                db.termin.create({redovni:true,dan:req.query.dan,semestar:sem,pocetak:req.query.pocetak,kraj:req.query.kraj}).then(function(){
                                    db.termin.findOne({where:{dan:req.query.dan,pocetak:req.query.pocetak,kraj:req.query.kraj}}).then(function(ot2){
                                        //Promise.all(ot2);
                                        //console.log(ot2);
                                        db.rezervacija.create({termin:ot2.id,sala:os.id,osoba:oo.id}).then(function(){
                                            db.rezervacija.findAll().then(function(or){
                                                var per=[];
                                                var van=[];
                                                var idemo=or.length;
                                                //console.log("id "+idemo);
                                                for(var i=0;i<or.length;i++){
                                                    var ter=or[i].termin;
                                                    var sal=or[i].sala; 
                                                    var oso=or[i].osoba
                                                    //console.log(ter+" "+sal+" "+oso);
                                                    var termin_n;
                                                    var osoba_n;
                                                    var sala_n;
                                                    db.termin.findOne({where:{id:ter}}).then(function(ot){
                                                        //console.log("sss "+ot.length);
                                                        termin_n=ot;
                                                        db.sala.findOne({where:{id:sal}}).then(function(os){
                                                            //console.log(os.naziv);
                                                            sala_n=os;
                                                            db.osoblje.findOne({where:{id:oso}}).then(function(oo){
                                                                //console.log("ocaj "+termin_n.redovni);
                                                                osoba_n=oo;
                                                                if(termin_n.redovni==true){
                                                                    var obj={"dan":termin_n.dan,"semestar":termin_n.semestar,"pocetak":termin_n.pocetak,"kraj":termin_n.kraj,"naziv":sala_n.naziv,"predavac":osoba_n.ime};
                                                                    //console.log(obj);
                                                                    per.push(obj);
                                                                }
                                                                else{
                                                                    var ob2={"datum":termin_n.datum,"pocetak":termin_n.pocetak,"kraj":termin_n.kraj,"naziv":sala_n.naziv,"predavac":osoba_n.ime};
                                                                    //console.log(ob2);
                                                                    van.push(ob2);
                                                                }
                                                                if(per.length+van.length===idemo){
                                                                    //console.log("kraj "+per.length+" "+van.length);
                                                                    //console.log(per);
                                                                    //console.log(van);
                                                
                                                                    var ob_per={"periodicna":per,"vandredna":van};
                                                                    //console.log(ob_per);
                                                                    res.send(ob_per);
                                                                    //return ob_per;
                                                                }
                                                                
                                                            });
                                                        });
                                        
                                                    });
                                                    
                                                    
                                                }
                                                //console.log(per);
                                            });
                                        });
                                    });
                                });
                            }
                            else{
                                console.log("ovdjeee");
                                console.log("ids osobe "+tt[i].id);
                                db.rezervacija.findOne({where:{termin:tt[i].id}}).then(function(orr){
                                    db.osoblje.findOne({where:{id:orr.osoba}}).then(function(ooo){
                                        res.send({"ime":ooo.ime,"prezime":ooo.prezime});
                                    });
                                });
                                
                            }*/
                        
                        });
                        

                        
                



                        

                    }
                    else{

                        console.log("id osobe "+ot.id+" id sala "+os.id);

                        db.rezervacija.findOne({where:{sala:os.id,termin:ot.id}}).then(function(oor){
                            if(oor===null){
                                db.termin.create({redovni:true,dan:req.query.dan,semestar:sem,pocetak:req.query.pocetak,kraj:req.query.kraj}).then(function(){
                                    db.termin.findOne({where:{dan:req.query.dan,pocetak:req.query.pocetak,kraj:req.query.kraj}}).then(function(ot2){
                                        //Promise.all(ot2);
                                        //console.log(ot2);
                                        db.rezervacija.create({termin:ot2.id,sala:os.id,osoba:oo.id}).then(function(){
                                            db.rezervacija.findAll().then(function(or){
                                                var per=[];
                                                var van=[];
                                                var idemo=or.length;
                                                //console.log("id "+idemo);
                                                for(var i=0;i<or.length;i++){
                                                    var ter=or[i].termin;
                                                    var sal=or[i].sala; 
                                                    var oso=or[i].osoba
                                                    //console.log(ter+" "+sal+" "+oso);
                                                    var termin_n;
                                                    var osoba_n;
                                                    var sala_n;
                                                    db.termin.findOne({where:{id:ter}}).then(function(ot){
                                                        //console.log("sss "+ot.length);
                                                        termin_n=ot;
                                                        db.sala.findOne({where:{id:sal}}).then(function(os){
                                                            //console.log(os.naziv);
                                                            sala_n=os;
                                                            db.osoblje.findOne({where:{id:oso}}).then(function(oo){
                                                                //console.log("ocaj "+termin_n.redovni);
                                                                osoba_n=oo;
                                                                if(termin_n.redovni==true){
                                                                    var obj={"dan":termin_n.dan,"semestar":termin_n.semestar,"pocetak":termin_n.pocetak,"kraj":termin_n.kraj,"naziv":sala_n.naziv,"predavac":osoba_n.ime};
                                                                    //console.log(obj);
                                                                    per.push(obj);
                                                                }
                                                                else{
                                                                    var ob2={"datum":termin_n.datum,"pocetak":termin_n.pocetak,"kraj":termin_n.kraj,"naziv":sala_n.naziv,"predavac":osoba_n.ime};
                                                                    //console.log(ob2);
                                                                    van.push(ob2);
                                                                }
                                                                if(per.length+van.length===idemo){
                                                                    //console.log("kraj "+per.length+" "+van.length);
                                                                    //console.log(per);
                                                                    //console.log(van);
                                                
                                                                    var ob_per={"periodicna":per,"vandredna":van};
                                                                    //console.log(ob_per);
                                                                    res.send(ob_per);
                                                                    //return ob_per;
                                                                }
                                                                
                                                            });
                                                        });
                                        
                                                    });
                                                    
                                                    
                                                }
                                                //console.log(per);
                                            });
                                        });
                                    });
                                });
                            }
                            else{
                                db.rezervacija.findOne({where:{termin:tt[i].id}}).then(function(orr){
                                    db.osoblje.findOne({where:{id:orr.osoba}}).then(function(ooo){
                                        res.send({"ime":ooo.ime,"prezime":ooo.prezime});
                                    });
                                });
                            }
                        });

                        
                    }

                });

            });

        });

        //console.log(os);


        /*fs.readFile('zauzeca.json',(err,data) =>{
            if(err) throw err;
            let zz=JSON.parse(data);
            var niz_dat=zz['periodicna'];
            var mjs=req.query.mjesec;
            
            for(var i=0;i<niz_dat.length;i++){
                var sem= niz_dat[i].semestar;
                if((mjs>8 && mjs<12) || mjs==0){
                    if(sem=="ljetni")continue;
              
                    if(parseInt(req.query.dan)==niz_dat[i].dan && req.query.sala==niz_dat[i].naziv){
                        greska=true;
                        break;
                    }
                }
                else if(mjs>0 && mjs<6){
                    if(sem=="zimski")continue;
                    if(parseInt(req.query.dan)==niz_dat[i].dan && req.query.sala==niz_dat[i].naziv){
                        greska=true;
                        break;
                    }
                }
            }
            var niz_van=zz['vandredna'];
            for(var i=0;i<niz_van.length;i++){
                if((mjs>8 && mjs<12) || mjs==0){
                    
                    var dateString = niz_van[i].datum; // Oct 23

                    var dateParts = dateString.split(".");

                    var dateObject = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]); 

                    var god=+dateParts[2];
                    var mjesecc=dateParts[1] - 1;
                    var dann=+dateParts[0];
                    //ako je mjesec van zimskog semestra
                    if(mjesecc>0 && mjesecc<9)continue;

                    var firstDay =  new Date(dateObject.getFullYear(), mjesecc, 1); 
                    var s=firstDay.getDay();

                    var dd;
                    if(s===0){
                        s=6;
                        dd=(s-1)+parseInt(dann);
                    }else{
                        dd=(s-2)+parseInt(dann);
                    }
    
                    dd=dd%7;
                    if(dd==parseInt(req.query.dan) && niz_van[i].naziv==req.query.sala){
                        
                        greska=true;
                        
                        break;
                    }
                }
                else if(mjs>0 && mjs<6){
                    
                    var dateString = niz_van[i].datum; // Oct 23

                    var dateParts = dateString.split(".");

                    var dateObject = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]); 

                    var god=+dateParts[2];
                    var mjesecc=dateParts[1] - 1;
                    var dann=+dateParts[0];

                    //ako je mjesec van ljetnog semestra
                    if((mjesecc>8 && mjesecc<12) || mjesecc==0)continue;
                    var firstDay =  new Date(dateObject.getFullYear(), mjesecc, 1); 
                    var s=firstDay.getDay();

                    var dd;
                    if(s===0){
                        s=6;
                        dd=(s-1)+parseInt(dann);
                    }else{
                        dd=(s-2)+parseInt(dann);
                    }
    
                    dd=dd%7;
                    if(dd==parseInt(req.query.dan)){
                        greska=true;
                    }
                }
            }
            if(req.query.mjesec>0 && req.query.mjesec<6){
                zz['periodicna'].push({"dan":parseInt(req.query.dan),"semestar":"ljetni","pocetak":req.query.pocetak,"kraj":req.query.kraj,"naziv":req.query.sala,"predavac":"novi"});

            }
            else if((req.query.mjesec>8 && req.query.mjesec<12) || req.query.mjesec==0){
                zz['periodicna'].push({"dan":parseInt(req.query.dan),"semestar":"zimski","pocetak":req.query.pocetak,"kraj":req.query.kraj,"naziv":req.query.sala,"predavac":"novi"});
            }
            
            if(greska==false){
                    fs.writeFile('zauzeca.json',JSON.stringify(zz),(err) =>{
                        if(err) throw err;
                        
                        res.sendFile(__dirname+"/zauzeca.json");
                    });
            
        }
        else{
            
            var godina=new Date();
            var mj=parseInt(req.query.mjesec)+1;
            res.send({"mesage":"Nije moguće rezervisati salu "+req.query.sala +" za navedeni datum "+req.query.datum+"/"+mj+"/"+godina.getFullYear()+" i termin od "+req.query.pocetak +" do " +req.query.kraj+"!"});
        }
        });*/
        
});

app.post('/upisivan',function(req,res){
    

        var godina=new Date();
        var mj=parseInt(req.query.mjesec)+1;
        var dat=req.query.datum+"."+mj+"."+godina.getFullYear()

        console.log(dat);


        db.sala.findOne({where:{naziv:req.query.sala}}).then(function(os){
            bsala=os;
            //console.log(os.length);
            //console.log(os);
            //res.send(JSON.stringify(os));

            db.osoblje.findOne({where:{ime:req.query.ime}}).then(function(oo){
                //console.log(oo);

                //,pocetak:req.query.pocetak,kraj:req.query.kraj
                db.termin.findOne({where:{datum:dat,pocetak:req.query.pocetak,kraj:req.query.kraj}}).then(function(ot){
                    console.log(ot);
                    if(ot===null){
                        db.termin.create({redovni:false,datum:dat,pocetak:req.query.pocetak,kraj:req.query.kraj}).then(function(){
                            db.termin.findOne({where:{datum:dat,pocetak:req.query.pocetak,kraj:req.query.kraj}}).then(function(ot2){
                                //Promise.all(ot2);
                                //console.log(ot2);
                                db.rezervacija.create({termin:ot2.id,sala:os.id,osoba:oo.id}).then(function(){
                                    console.log("ovdje je hak");
                                    db.rezervacija.findAll().then(function(or){
                                        var per=[];
                                        var van=[];
                                        var idemo=or.length;
                                        //console.log("id "+idemo);
                                        for(var i=0;i<or.length;i++){
                                            var ter=or[i].termin;
                                            var sal=or[i].sala; 
                                            var oso=or[i].osoba
                                            //console.log(ter+" "+sal+" "+oso);
                                            var termin_n;
                                            var osoba_n;
                                            var sala_n;
                                            db.termin.findOne({where:{id:ter}}).then(function(ot){
                                                //console.log("sss "+ot.length);
                                                termin_n=ot;
                                                
                                
                                            });
                                            db.sala.findOne({where:{id:sal}}).then(function(os){
                                                //console.log(os.naziv);
                                                sala_n=os;
                                            });
                                            db.osoblje.findOne({where:{id:oso}}).then(function(oo){
                                                //console.log("ocaj "+termin_n.redovni);
                                                osoba_n=oo;
                                                if(termin_n.redovni==true){
                                                    var obj={"dan":termin_n.dan,"semestar":termin_n.semestar,"pocetak":termin_n.pocetak,"kraj":termin_n.kraj,"naziv":sala_n.naziv,"predavac":osoba_n.ime};
                                                    //console.log(obj);
                                                    per.push(obj);
                                                }
                                                else{
                                                    var ob2={"datum":termin_n.datum,"pocetak":termin_n.pocetak,"kraj":termin_n.kraj,"naziv":sala_n.naziv,"predavac":osoba_n.ime};
                                                    //console.log(ob2);
                                                    van.push(ob2);
                                                }
                                                if(per.length+van.length===idemo){
                                                    //console.log("kraj "+per.length+" "+van.length);
                                                    //console.log(per);
                                                    //console.log(van);
                                
                                                    var ob_per={"periodicna":per,"vandredna":van};
                                                    console.log(ob_per);
                                                    res.send(ob_per);
                                                    //return ob_per;
                                                }
                                                
                                            });
                                        }
                                        //console.log(per);
                                    });
                                });
                                //res.send();
                                //var ss=dajPodatke();
                                console.log("ss");
                                

                                


                            });
                        });

                    }
                    else{
                        
                        
                        db.rezervacija.findOne({where:{termin:ot.id}}).then(function(orr){
                            console.log("sala "+orr.sala+" sala2 "+os.id);
                            if(orr.sala!=os.id){
                                console.log("sss");
                                db.termin.create({redovni:false,datum:dat,pocetak:req.query.pocetak,kraj:req.query.kraj}).then(function(){
                                    db.termin.findOne({where:{datum:dat,pocetak:req.query.pocetak,kraj:req.query.kraj}}).then(function(ot2){
                                        //Promise.all(ot2);
                                        //console.log(ot2);
                                        db.rezervacija.create({termin:ot2.id,sala:os.id,osoba:oo.id}).then(function(){
                                            console.log("ovdje je hak");
                                            db.rezervacija.findAll().then(function(or){
                                                var per=[];
                                                var van=[];
                                                var idemo=or.length;
                                                //console.log("id "+idemo);
                                                for(var i=0;i<or.length;i++){
                                                    var ter=or[i].termin;
                                                    var sal=or[i].sala; 
                                                    var oso=or[i].osoba
                                                    //console.log(ter+" "+sal+" "+oso);
                                                    var termin_n;
                                                    var osoba_n;
                                                    var sala_n;
                                                    db.termin.findOne({where:{id:ter}}).then(function(ot){
                                                        //console.log("sss "+ot.length);
                                                        termin_n=ot;
                                                        
                                        
                                                    });
                                                    db.sala.findOne({where:{id:sal}}).then(function(os){
                                                        //console.log(os.naziv);
                                                        sala_n=os;
                                                    });
                                                    db.osoblje.findOne({where:{id:oso}}).then(function(oo){
                                                        //console.log("ocaj "+termin_n.redovni);
                                                        osoba_n=oo;
                                                        if(termin_n.redovni==true){
                                                            var obj={"dan":termin_n.dan,"semestar":termin_n.semestar,"pocetak":termin_n.pocetak,"kraj":termin_n.kraj,"naziv":sala_n.naziv,"predavac":osoba_n.ime};
                                                            //console.log(obj);
                                                            per.push(obj);
                                                        }
                                                        else{
                                                            var ob2={"datum":termin_n.datum,"pocetak":termin_n.pocetak,"kraj":termin_n.kraj,"naziv":sala_n.naziv,"predavac":osoba_n.ime};
                                                            //console.log(ob2);
                                                            van.push(ob2);
                                                        }
                                                        if(per.length+van.length===idemo){
                                                            //console.log("kraj "+per.length+" "+van.length);
                                                            //console.log(per);
                                                            //console.log(van);
                                        
                                                            var ob_per={"periodicna":per,"vandredna":van};
                                                            console.log(ob_per);
                                                            res.send(ob_per);
                                                            //return ob_per;
                                                        }
                                                        
                                                    });
                                                }
                                                //console.log(per);
                                            });
                                        });
                                        //res.send();
                                        //var ss=dajPodatke();
                                        console.log("ss");
                                        
        
                                        
        
        
                                    });
                                });
                            }
                            else{
                                db.osoblje.findOne({where:{id:orr.osoba}}).then(function(ooo){
                                    res.send({"ime":ooo.ime,"prezime":ooo.prezime});
                                });
                            }
                            
                        });


                    }
                });

            });

        });

        
       
        




        /*var greska=false;

        fs.readFile('zauzeca.json',(err,data) =>{
            if(err) throw err;
            let zz=JSON.parse(data);
            var mj=parseInt(req.query.mjesec)+1;
            var dat_dol=req.query.datum+"."+mj+"."+godina.getFullYear();
            var niz_van=zz['vandredna'];
            for(var i=0;i<niz_van.length;i++){
                if(niz_van[i].datum==dat_dol){
                    greska=true;
                }
            }
            zz['vandredna'].push({"datum":req.query.datum+"."+mj+"."+godina.getFullYear(),"pocetak":req.query.pocetak,"kraj":req.query.kraj,"naziv":req.query.sala,"predavac":"novi"});
            
            if(greska==false){
            fs.writeFile('zauzeca.json',JSON.stringify(zz),(err) =>{
                if(err) throw err;
                res.sendFile(__dirname+"/zauzeca.json");
            });
        }
        else{
            res.send({"mesage":"Nije moguće rezervisati salu "+req.query.sala +" za navedeni datum "+req.query.datum+"/"+mj+"/"+godina.getFullYear()+" i termin od "+req.query.pocetak +" do " +req.query.kraj+"!"});
        }
        });*/
        
        
});

app.get('/ucitajsl',function(req,res){
    if(req.query.br==1){
        res.json({slika1:"https://upload.wikimedia.org/wikipedia/commons/a/a5/20150331_2026_AUT_BIH_2177_Edin_D%C5%BEeko.jpg",slika2:"http://radiobet.eu/wp-content/uploads/2017/11/b_171111090.jpg",slika3:"https://storage.radiosarajevo.ba/image/448088/1180x732/BiH_Grcka_Bilino_2019_mart_RSA_DZ_K010.jpg"});
    }
    else if(req.query.br==2){
        res.json({slika1:"https://storage.radiosarajevo.ba/image/243045/1180x732/Zvjezdan_misimovic.jpg",slika2:"https://www.life.ba/wp-content/uploads/2013/12/aa_picture_20131226_1248251_high.jpg",slika3:"https://www.nfsbih.ba/images/2019-D/010_oktobar/dinko_-_gojak.jpg"});
    }
    else if(req.query.br==3){
        res.json({slika1:"https://www.dulist.hr/wp-content/uploads/2019/08/spahic.jpg",slika2:"https://www.inmedia.ba/wp-content/uploads/2017/06/sead.jpg",slika3:"https://storage.radiosarajevo.ba/image/315024/1180x732/Muhamed_Besic_1_RSA.jpg"});
    }
    else{
        res.json({slika1:"https://storage.bljesak.info/image/290861/1280x880/Edin-Visca.jpg"});

    }
});


app.get('/osoblje',function(req,res){
    db.osoblje.findAll().then(function(os){
        //console.log(os.length);
        //res.status(200);
        //res.setHeader('Content-Type', 'application/json');
        res.send(JSON.stringify(os));
    });
});
app.get('/sala',function(req,res){
    db.sala.findAll().then(function(os){
        //console.log(os.length);
        res.send(JSON.stringify(os));
    });
});

app.get('/osobljeKancelarije',function(req,res){

    console.log("dan u sed "+req.query.dan+" datum "+req.query.datum);
    /*db.termin.findAll().then(function(tt){
        for(var i=0;i<tt.length;i++){


            if(tt[i].redovni==true && tt[i].dan==req.query.dan){
                console.log("termini");
                console.log(tt[i].pocetak+" "+tt[i].kraj);


                var s_poc=tt[i].pocetak;
        var s_kraj=tt[i].kraj;
        var str_poc=s_poc.split(":");
        var str_kraj=s_kraj.split(":");
        var poc_sat=+str_poc[0];
        var poc_min=+str_poc[1];
        var kraj_sat=+str_kraj[0];
        var kraj_min=+str_kraj[1];

        var str_p_poc=req.query.pocetak.split(":");
        var p_poc_sat=+str_p_poc[0];
        var p_poc_min=+str_p_poc[1];

        var str_p_kraj=req.query.kraj.split(":");
        var p_kraj_sat=+str_p_kraj[0];
        var p_kraj_min=+str_p_kraj[1];

            if(((req.query.pocetak===tt[i].pocetak && req.query.kraj===tt[i].kraj) 
            || (( (p_poc_sat>poc_sat) || (p_poc_sat==poc_sat && p_poc_min>=poc_min)) && (  (p_poc_sat<kraj_sat) || (p_poc_sat==kraj_sat && p_poc_min<kraj_min)) )
            || (((p_kraj_sat<kraj_sat ) || (p_kraj_sat==kraj_sat && p_kraj_min<kraj_min)) && ((p_kraj_sat>poc_sat) || (p_kraj_sat==poc_sat && p_kraj_min>poc_min))      )
            || (((p_poc_sat<poc_sat) || (p_poc_sat==poc_sat && p_poc_min<=poc_min)) && ((p_kraj_sat>kraj_sat ) || (p_kraj_sat==kraj_sat && p_kraj_min>=kraj_min)))
            )){

            
                console.log("ssss"+tt[i].pocetak+" "+tt[i].kraj);
                console.log("termin id "+tt[i].id);
                var oso;
                db.rezervacije.findOne({where:{termin:tt[i].id}}).then(function(or){
                    oso=or.osoba;
                    console.log("osovba "+oso);
                    db.osoblje.findOne({where:{id:oso}}).then(function(oo){
                        console.log("osoba "+oo.ime);
                    });
                });

                

            }



            }

        }
    });*/

    var niz=[];
    var brojac=0;
    db.osoblje.findAll().then(function(os){
        //console.log(os.length);
        let br=os.length;
//var osss;
        for(var i=0;i<os.length;i++){
            var osss=os[i];
            var salaa;
            //brojac++;
            let ime=osss.ime;
            console.log("ime "+osss.ime);
            let brr=0;
            let nn=false;
            
            db.rezervacija.findAll({where:{osoba:os[i].id}}).then(function(or){
                //console.log("dutt  "+or.length);
                //console.log("sada ime "+os[i].ime);
                console.log(ime+" duzina "+or.length);
                let bs=or.length;
                console.log("duzz "+bs);
                if(or.length==0){
                    console.log(ime+" je sigurno u kac");
                    niz.push({"ime":ime,"sala":"kancelarija"});
                    brojac++;
                }
                for(var j=0;j<or.length;j++){
                    //console.log("sala  "+or[j].sala);
                    var ssss=or[j].sala;
                    db.termin.findOne({where:{id:or[j].termin}}).then(function(tt){
                        
                        if(tt.redovni==true && tt.dan==req.query.dan){
                            var s_poc=tt.pocetak;
                            var s_kraj=tt.kraj;
                            var str_poc=s_poc.split(":");
                            var str_kraj=s_kraj.split(":");
                            var poc_sat=+str_poc[0];
                            var poc_min=+str_poc[1];
                            var kraj_sat=+str_kraj[0];
                            var kraj_min=+str_kraj[1];
                    
                            var str_p_poc=req.query.pocetak.split(":");
                            var p_poc_sat=+str_p_poc[0];
                            var p_poc_min=+str_p_poc[1];
                    
                            var str_p_kraj=req.query.kraj.split(":");
                            var p_kraj_sat=+str_p_kraj[0];
                            var p_kraj_min=+str_p_kraj[1];
                    
                    
                            if(((req.query.pocetak===tt.pocetak && req.query.kraj===tt.kraj) 
                            || (( (p_poc_sat>poc_sat) || (p_poc_sat==poc_sat && p_poc_min>=poc_min)) && (  (p_poc_sat<kraj_sat) || (p_poc_sat==kraj_sat && p_poc_min<kraj_min)) )
                            || (((p_kraj_sat<kraj_sat ) || (p_kraj_sat==kraj_sat && p_kraj_min<kraj_min)) && ((p_kraj_sat>poc_sat) || (p_kraj_sat==poc_sat && p_kraj_min>poc_min))      )
                            || (((p_poc_sat<poc_sat) || (p_poc_sat==poc_sat && p_poc_min<=poc_min)) && ((p_kraj_sat>kraj_sat ) || (p_kraj_sat==kraj_sat && p_kraj_min>=kraj_min)))
                            )){
                                db.sala.findOne({where:{id:ssss}}).then(function(oss){
                                    salaa=oss.naziv;
                                    //console.log("imeeee "+ime);
                                    console.log(ime+" je u sali "+salaa);
                                    brojac++;
                                    brr++;
                                    var ss=niz.find(obj=>obj.ime===ime);
                                    if(ss==null){
                                        niz.push({"ime":ime,"sala":salaa});
                                    }
                                    else{
                                        ss=niz.find(obj=>obj.ime===ime).ime;
                                    }
                                    if(ss!==null){
                                        console.log("prije "+niz.find(obj=>obj.ime===ime).sala);
                                        var s=niz.find(obj=>obj.ime===ime).sala=salaa;
                                        console.log("poslije "+niz.find(obj=>obj.ime===ime).sala);
                                        //brojac++;
                                        if(nn)
                                        brojac--;
                                        nn=true;
                                       
                                    }else{
                                        niz.push({"ime":ime,"sala":salaa});
                                    }
                                    
                                    //console.log("sss1 "+br+" "+brojac);
                                    console.log("s "+brojac+" "+br+" sss "+bs+" "+brr);
                                    /*if(brr!=bs){
                                        brojac--;
                                    }*/
                                    if(brojac==br && bs==brr){
                                        console.log("niz");
                                        res.send(niz);
                                    }
                                });
                                
                            }
                            else{
                                niz.push({"ime":ime,"sala":"kancelarija"});
                                
                            }
                            
                        }
                        else if(tt.redovni==false && tt.datum==req.query.datum){
                            var s_poc=tt.pocetak;
                            var s_kraj=tt.kraj;
                            var str_poc=s_poc.split(":");
                            var str_kraj=s_kraj.split(":");
                            var poc_sat=+str_poc[0];
                            var poc_min=+str_poc[1];
                            var kraj_sat=+str_kraj[0];
                            var kraj_min=+str_kraj[1];
                    
                            var str_p_poc=req.query.pocetak.split(":");
                            var p_poc_sat=+str_p_poc[0];
                            var p_poc_min=+str_p_poc[1];
                    
                            var str_p_kraj=req.query.kraj.split(":");
                            var p_kraj_sat=+str_p_kraj[0];
                            var p_kraj_min=+str_p_kraj[1];
                    
                    
                            if(((req.query.pocetak===tt.pocetak && req.query.kraj===tt.kraj) 
                            || (( (p_poc_sat>poc_sat) || (p_poc_sat==poc_sat && p_poc_min>=poc_min)) && (  (p_poc_sat<kraj_sat) || (p_poc_sat==kraj_sat && p_poc_min<kraj_min)) )
                            || (((p_kraj_sat<kraj_sat ) || (p_kraj_sat==kraj_sat && p_kraj_min<kraj_min)) && ((p_kraj_sat>poc_sat) || (p_kraj_sat==poc_sat && p_kraj_min>poc_min))      )
                            || (((p_poc_sat<poc_sat) || (p_poc_sat==poc_sat && p_poc_min<=poc_min)) && ((p_kraj_sat>kraj_sat ) || (p_kraj_sat==kraj_sat && p_kraj_min>=kraj_min)))
                            )){
                                db.sala.findOne({where:{id:ssss}}).then(function(oss){
                                    salaa=oss.naziv;
                                    brojac++;
                                    brr++;
                                    //console.log("imeeee "+ime);
                                    console.log(ime+" je u sali "+salaa);
                                    console.log(niz);
                                    //var ss=niz.find(obj=>obj.ime===ime).ime;
                                    var ss=niz.find(obj=>obj.ime===ime);
                                    if(ss==null){
                                        niz.push({"ime":ime,"sala":salaa});
                                    }
                                    else{
                                        ss=niz.find(obj=>obj.ime===ime).ime;
                                    }
                                    //niz.push({"ime":ime,"sala":salaa});
                                    if(ss!==null){
                                        console.log("prije "+niz.find(obj=>obj.ime===ime).sala);
                                        var s=niz.find(obj=>obj.ime===ime).sala=salaa;
                                        console.log("poslije "+niz.find(obj=>obj.ime===ime).sala);
                                        //brojac++;
                                    }else{
                                        niz.push({"ime":ime,"sala":salaa});
                                    }
                                    console.log("s "+brojac+" "+br+" sss "+bs+" "+brr);
                                    /*if(brr!=bs){
                                        brojac--;
                                    }*/
                                    if(brojac==br && bs==brr){
                                        console.log("niz1");
                                        res.send(niz);
                                    }
                                });
                            }
                            else{
                                console.log("ideees");
                                niz.push({"ime":ime,"sala":"kancelarija"});
                                
                            }
                        }
                        else{
                            console.log("ideee");
                            var ss=niz.find(obj=>obj.ime===ime);
                            if(ss==null){
                                console.log("null je");
                                niz.push({"ime":ime,"sala":"kancelarija"});
                            }
                            /*var ss=niz.find(obj=>obj.ime===ime).ime;
                            if(ss!==null){
                                
                            }else{
                                niz.push({"ime":ime,"sala":salaa});
                            }*/

                            //niz.push({"ime":ime,"sala":"kancelarija"});
                            brojac++;
                            brr++;
                            console.log(ime+" je u sali "+salaa);
                            console.log("s "+brojac+" "+br+" sss "+bs+" "+brr);
                            if(brr!=bs){
                                brojac--;
                            }
                            if(brojac==br && bs==brr){
                                console.log("niz11");
                                res.send(niz);
                            }
                        }
                        
                        
        
        

                    });
                }

            });
            //console.log(osss.ime+" u sali "+salaa);
            
        }
        console.log(niz);
        //res.send(JSON.stringify(os));
    });
});

module.exports= app.listen(8080);