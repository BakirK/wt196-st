const Sequelize = require("sequelize");
const sequelize = new Sequelize("DBWT19","root","root",
    {
        host: "127.0.0.1",
        dialect: "mysql",
        logging: false,

        pool: {
            max: 5,
            min: 0,
            idle: 10000
        }
    });

const db={};

console.log("Konekcija ostvarena!");

db.Sequelize = Sequelize;  
db.sequelize = sequelize;

//import modela
db.Osoblje = sequelize.import(__dirname+'/Osoblje.js');
db.Rezervacija = sequelize.import(__dirname+'/Rezervacija.js');
db.Termin = sequelize.import(__dirname+'/Termin.js');
db.Sala = sequelize.import(__dirname+'/Sala.js');

//Veze izmedju objekata
db.Osoblje.hasOne(db.Sala, {foreignKey: {name: 'zaduzenaOsoba', type: Sequelize.INTEGER}});
db.Sala.belongsTo(db.Osoblje, {foreignKey: {name: 'zaduzenaOsoba', type: Sequelize.INTEGER}});

db.Termin.hasOne(db.Rezervacija, {foreignKey: {name: 'termin', type : Sequelize.INTEGER, unique: true}});
db.Rezervacija.belongsTo(db.Termin, {foreignKey: {name:'termin',type : Sequelize.INTEGER, unique: true}});

db.Rezervacija.belongsTo(db.Sala, {foreignKey: {name: 'sala', type : Sequelize.INTEGER}});
db.Sala.hasMany(db.Rezervacija, {foreignKey: {name:'sala',type : Sequelize.INTEGER}});

db.Rezervacija.belongsTo(db.Osoblje, {foreignKey: {name: 'osoba', type: Sequelize.INTEGER}});
db.Osoblje.hasMany(db.Rezervacija, {foreignKey: {name: 'osoba', type: Sequelize.INTEGER}});





module.exports = db;