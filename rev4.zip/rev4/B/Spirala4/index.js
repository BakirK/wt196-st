var http = require('http');
var fs = require('fs');
var Sequilize = require('sequelize');
var fsa = require('fs-extra');
var url = require('url');
const bodyParser = require('body-parser');
var express = require('express');
var path = require('path');
var banana = JSON.parse(fs.readFileSync('zauzeca.json', 'utf8'))
var _ = require('underscore');
var mysql = require('mysql');
//NESTO ZA PORT, NE ZNAM JOS STA
const PORT = process.env.PORT || 8080;

//Ovo je nasa konekcija i baza i sve
const db = require('./db.js');



//Ovdje vrsimo unos u bazu
db.sequelize.sync({force: true}).then(function(){
    let promises = [];
    promises.push(db.Osoblje.create({
        ime: "Neko",
        prezime: "Nekić",
        uloga: "profesor"
    }));
    promises.push(db.Osoblje.create({
        ime: "Drugi",
        prezime: "Neko",
        uloga: "asistent"
    }));
    promises.push(db.Osoblje.create({
        ime: "Test",
        prezime: "Test",
        uloga: "asistent"
    }));

    Promise.all(promises).then(osobe => {
        let osoba1 = osobe.filter(o => o.ime == 'Neko' && o.prezime == 'Nekić')[0];
        let osoba2 = osobe.filter(o => o.ime == 'Drugi' && o.prezime == 'Neko')[0];
        let osoba3 = osobe.filter(o => o.ime == 'Test' && o.prezime == 'Test')[0];
        let sale = [];
        sale.push(db.Sala.create({
            naziv: "1-11",
            zaduzenaOsoba: 2
        }));
        sale.push(db.Sala.create({
            naziv: "1-15",
            zaduzenaOsoba: 1
        }));

        Promise.all(sale).then(sale => {
            let sala1 = sale.filter(s => s.naziv == '1-11')[0];
            let sala2 = sale.filter(s => s.naziv == '1-15')[0];
            let termini = [];
            termini.push(db.Termin.create({
                redovni: false,
                dan: null,
                datum: "01.01.2020",
                semestar: null,
                pocetak: "12:00",
                kraj: "13:00"
            }));
            termini.push(db.Termin.create({
                redovni: true,
                    dan: 0,
                    datum: null,
                    semestar: "zimski",
                    pocetak: "13:00",
                    kraj: "14:00"
            }));
            Promise.all(termini).then(termini => {
                termin1 = termini.filter(t => !t.redovni)[0];
                termin2 = termini.filter(t => t.redovni)[0];
                db.Rezervacija.create({}).then(rez => {
                    rez.sala = 1;
                    rez.termin = termin1.id;
                    rez.osoba = osoba1.id;
                    rez.save();
                });
                db.Rezervacija.create({}).then(rez => {
                    rez.sala = 1;
                    rez.termin = termin2.id;
                    rez.osoba = osoba3.id;
                    rez.save();
                });
            });

        });
    });

    console.log("Gotovo kreiranje tabela i ubacivanje pocetnih podataka!");
    

});


    var app = express();
    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({ extended: true }));

    app.use('/static', express.static(path.join(__dirname, 'public')));
    
    app.get('/', function(req, res) {
        console.log(req.url);   
            res.sendFile(path.join(__dirname, '/pocetna.html'));
    });

    app.get('/osoblje.html', function(req, res) {
        console.log(req.url);   
            res.sendFile(path.join(__dirname, '/osoblje.html'));
    });


    //Primamo sve slike ovdje
    app.get('/images', (req, res) => {
        console.log(req.url);
        fs.readdir([__dirname, '/images'].join(''), function (err, files) {
            let images = [];
            _.each(files, function(imageFIle) {
                let slike = fs.readFileSync([__dirname, '/images', '/', imageFIle].join(''));
                slike = "data:image/jpeg;base64," + new Buffer(slike).toString('base64');
                images.push(slike);
            })
            var podatci = JSON.stringify(images);
            res.writeHead(200, {'Content-Type': 'application/json'});
            res.end(podatci);
        })
    });


    app.get('/pocetna.html', function(req, res) {
        console.log(req.url);
            res.sendFile(path.join(__dirname, '/pocetna.html'));   
    });

    app.get('/rezervacija.html', function(req, res) {
        console.log(req.url);
        
        res.sendFile(path.join(__dirname, '/rezervacija.html'));    
    });

    app.get('/sale.html', function(req, res) {
        console.log(req.url);
            res.sendFile(path.join(__dirname, '/sale.html'));   
    });

    app.get('/unos.html', function(req, res) {
        console.log(req.url);
            res.sendFile(path.join(__dirname, '/unos.html')); 
    });

    app.get('/broj', function(req, res) {
        console.log(req.url);
        var sve = '<!DOCTYPE html>' +
        '<html>' +
            '<head>' +
                '<meta charset="UTF-8">' +
                '<link rel = "stylesheet" href = "/static/pocetna.css">' +
                '<meta name="viewport" content="width=device-width, initial-scale=1">' +
                
            '</head>' +
            '<body>' +
                '<div class = "meni">' +
                    '<div class = "logo">' +
                        '<img  id = "glavnaSlika" src = "/static/dizajn.jpg" alt="Ovdje nema slike :(">' +
                    '</div>' +
                    
                        '<ul id = "lista">' +
                            '<li>' +
                                '<a id = "linkPocetna" href ="pocetna.html">Početna</a>' +
                            '</li>' +
                            '<li>' +
                                '<a href ="sale.html">Sale</a>' +
                            '</li>' +
                            '<li>' +
                                '<a href ="unos.html"><u>Unos</u></a>' +
                            '</li>' +
                            '<li>' +
                                '<a href ="rezervacija.html"><u>Rezervacije</u></a>' +
                            '</li>' +
                            '<li>' +
                                '<a href =""><u>Osobe</u></a>' +
                            '</li>' +
                        '</ul>' +
                    
                             
                '</div>' +
                
                '<div class = "sadrzaj">' +
                    '<div class="grid-container">' +
                        '<div class="grid-item"><img id = "Slika1"  src = "/static/maca.jpg" alt = "Nema mace :("></div>' +
                        '<div class="grid-item"><img id = "Slika2" src = "/static/maca.jpg" alt = "Nema mace :("></div>' +
                        '<div class="grid-item"><img id = "Slika3" src = "/static/naocale.jpeg" alt = "Nema mace :("></div>' +
                        
                    '</div>' +
                '</div>' +
        
        
                '<input class = "dugmeK" id = "dugmea" type = "button" name = "prethodni" value = "Prethodni" onclick="prosleTri()">' +
                '<input class = "dugmeK" id = "dugmeZaNaprijeda" type = "button" name = "sljedeci" value = "Sljedeći" onclick="sljedeceTri()">' +
                '<a href="https://www.hitwebcounter.com" target="_blank">' +
    '<img src="https://hitwebcounter.com/counter/counter.php?page=7177012&style=0003&nbdigits=5&type=page&initCount=0" title="Visits Count" Alt="analytics counter"   border="0" >' +
    '</a>' +              

    
    '<a href="https://www.hitwebcounter.com" target="_blank">' +
    '<img src="https://hitwebcounter.com/counter/counter.php?page=7177016&style=0003&nbdigits=5&type=ip&initCount=0" title="Visits Count" Alt="analytics counter"   border="0" >' +
    '</a>' +


        '<script src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.6.0/underscore.js" type="text/javascript"></script>' +
        '<script type="text/javascript" src = "/static/kalendar.js"></script>' +
        '<script type="text/javascript" src = "/static/pocetna.js"></script>' +
        
    '</body>' +
'</html>';

        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(sve);  
    });


    //Vracanje svih sala
    app.get('/sveSale', function(req, res) {
        db.Sala.findAll().then(function(rez) {
            //console.log(rez);
            var zaPolje = "";
            //Uzimamo ono sto zelimo iz nase baze i saljemo nazad u callback da se odradi neki posao
            for(var i = 0; i < rez.length;i++) {
                //console.log(rez[i].ime.toString());
                zaPolje += rez[i].naziv + " " + rez[i].zaduzenaOsoba.toString() + '\n';
            }
            console.log(zaPolje);
            res.send(zaPolje);
        });
    });


    //OVO JE ZA PRIKAZ OVE RAJE
    app.get('/osobe', function(req, res) {
        var date = new Date();
        console.log(date);
        var zaPolje = "";
        db.Osoblje.findAll().then(function(rez) {
            //console.log(rez);
            var zaPolje = "";
            //Uzimamo ono sto zelimo iz nase baze i saljemo nazad u callback da se odradi neki posao
            for(var i = 0; i < rez.length;i++) {
                //console.log(rez[i].ime.toString());
                zaPolje += rez[i].ime.toString() + " " + rez[i].prezime.toString() + " " + rez[i].uloga.toString() + '\n';
            }
            var nak = zaPolje.split('\n');
            var sve = '<!DOCTYPE html>' +
        '<html>' +
            '<head>' +
                '<meta charset="UTF-8">' +
                '<link rel = "stylesheet" href = "/static/pocetna.css">' +
                '<meta name="viewport" content="width=device-width, initial-scale=1">' +
                
            '</head>' +
            '<body>' +
                '<div class = "meni">' +
                    '<div class = "logo">' +
                        '<img  id = "glavnaSlika" src = "/static/dizajn.jpg" alt="Ovdje nema slike :(">' +
                    '</div>' +
                    
                        '<ul id = "lista">' +
                            '<li>' +
                                '<a id = "linkPocetna" href ="pocetna.html">Početna</a>' +
                            '</li>' +
                            '<li>' +
                                '<a href ="sale.html">Sale</a>' +
                            '</li>' +
                            '<li>' +
                                '<a href ="unos.html"><u>Unos</u></a>' +
                            '</li>' +
                            '<li>' +
                                '<a href ="rezervacija.html"><u>Rezervacije</u></a>' +
                            '</li>' +
                            '<li>' +
                                '<a href ="osoblje.html"><u>Osobe</u></a>' +
                            '</li>' +
                        '</ul>' +
                    
                             
                '</div>' +
                
                '<div class = "sadrzaj">' +
                '<p id = "o1">'+ nak[0] + 'je u kancelariji' +'</p>' +
                '<p id = "o1">'+ nak[1] + 'je u kancelariji' + '</p>' +
                '<p id = "o1">'+ nak[2] + 'je u kancelariji' + '</p>' +
                '</div>' +
   

        '<script type="text/javascript" src = "/static/osob.js"></script>'+
        
    '</body>' +
'</html>';
            res.send(sve);
        });      
    });


    //OVO JE GOTOVO, SLUZI ZA UNOSENJE U SELECT POLJE, NE TREBA VISE//GOTOVO SKROZ ZADATAK 1
    //Zahtjev za vracanje svih podataka iz osoblja
    app.get('/osoblje', function(req, res) {
        db.Osoblje.findAll().then(function(rez) {
            //console.log(rez);
            var zaPolje = "";
            //Uzimamo ono sto zelimo iz nase baze i saljemo nazad u callback da se odradi neki posao
            for(var i = 0; i < rez.length;i++) {
                //console.log(rez[i].ime.toString());
                zaPolje += rez[i].ime.toString() + " " + rez[i].prezime.toString() + " " + rez[i].uloga.toString() + '\n';
            }
            res.send(zaPolje);
        });
    });

    //ODGOVOR AKO JE NESTO REZERVISANO URADJENO//GOTOVO RADI
    app.post('/rezervisiNE', function(req, res) {
        let tijelo = req.body;
        let predavac = tijelo.predavac;
        var tek = predavac.split(" ");
        res.send(tek[0] + " "  + tek[1] + " " + tek[2]);
    });

    //DRUGI ZADATAK, STAVLJANJE REZERVACIJE NA SERVER//GOTOVO//RADI KONACNO
    app.post('/rezervisi', function(req, res) {    
        let tijelo = req.body;
        //Ako se preda specifican JSON koji ce regulisati sta se treba izvrsavati, "nekaHvala" je kriterij
        if(tijelo.predavac == "nekaHvala") {
            res.json(tijelo); 
        } else {
               //console.log(tijelo);
                var tek = tijelo.predavac.split(" ");
                //console.log(tek[0]);
                var sal = tijelo.naziv;
                
                //Ovdje uzimamo nas dan koji cemo koristiti da odredimo koji je
                var dank = "";
                dank += tijelo.datum[0] +tijelo.datum[1];

                //Da znamo koji je semestar u pitanju
                var sem = "";
                sem += tijelo.datum[3];
                if(sem == "11" || sem == "10" || sem == "9" || sem == "0") {
                    sem = "zimski";
                } else if(sem == "1" || sem.toString() == "2" || sem.toString() == "3" || sem.toString() == "4" || sem.toString() == "5") {
                    sem = "ljetni";
                }
                

                var vrsta = tijelo.vrsta;
                console.log(vrsta);
                var zaDatum;
                if(vrsta) {
                    zaDatum = null;
                } else {
                    zaDatum = tijelo.datum;
                }
                var zaSem;
                if(sem != "zimski" || sem != "ljetni") {
                    zaSem = null;
                } else {
                    zaSem = sem;
                }

                
                //Kreiramo jedan novi termin i nakon toga i jednu rezervaciju//odnosno zbog nekog buga u kodu se kreiraju dva apsolutno ista, ali s aspekta logike nista ne remeti ovo jer su sve isti podatci, te jedna te ista osoba nesto rezervise
                if(tijelo.vrsta == false) {
                    let promise = [];
                    promise.push(db.Termin.create({
                        redovni: tijelo.vrsta,
                        dan: null,
                        datum: zaDatum,
                        semestar: zaSem,
                        pocetak: tijelo.pocetak,
                        kraj: tijelo.kraj
                    }));
                    Promise.all(promise).then(termini => {
                        termin1 = termini.filter(t => !t.redovni)[0];
                        console.log(termin1);
                        console.log(termin1.id);
                        let prom2 = [];
                        prom2.push(db.Osoblje.findOne({where: {ime: tek[0]}}));
                        prom2.push(db.Sala.findOne({where: {naziv: sal}}));
                        Promise.all(prom2).then(rez => {
                            var osobaa = rez[0].id;
                            console.log(osobaa);
                            var hah = rez[1].id;
                            console.log(tek[0].length);
                            db.Rezervacija.create({}).then(rek => {
                                rek.sala = hah;
                                rek.termin = termin1.id;
                                rek.osoba = osobaa;
                                rek.save();
                            });
                        });
                    });
                } else if(tijelo.vrsta == true) {
                    let promise = [];
                    promise.push(db.Termin.create({
                        redovni: 1,
                        dan: null,
                        datum: null,
                        semestar: null,
                        pocetak: tijelo.pocetak,
                        kraj: tijelo.kraj
                    }));
                    Promise.all(promise).then(termini => {
                        termin1 = termini.filter(t => !t.redovni)[0];
                        console.log(termin1);
                        console.log(termin1.id);
                        let prom2 = [];
                        prom2.push(db.Osoblje.findOne({where: {ime: tek[0]}}));
                        prom2.push(db.Sala.findOne({where: {naziv: sal}}));
                        Promise.all(prom2).then(rez => {
                            var osobaa = rez[0].id;
                            console.log(osobaa);
                            var hah = rez[1].id;
                            console.log(tek[0].length);
                            db.Rezervacija.create({}).then(rek => {
                                rek.sala = hah;
                                rek.termin = termin1.id + 1;
                                rek.osoba = osobaa;
                                rek.save();
                            });
                        });
                    });
                }                   
        }
        res.send("bla bla");  
    });


    
    //TREBA MI
    app.get('/osobaKojaJeRezervisala', function(req, res) {
        let tijelo = req.body;
    });

    //NE TREBA MI
    //Post zahtjev za zauzeca
    app.post('/zauzeca.json', function(req, res) {    
        let tijelo = req.body;
        //Ako se preda specifican JSON koji ce regulisati sta se treba izvrsavati, "nekaHvala" je kriterij
        if(tijelo.predavac == "nekaHvala") {
            res.json(tijelo); 
        } else {
            //Guramo u nas zauzeca.json novi red
            //banana je ustvari citav json fajl
            banana.vanredna.push(tijelo);
            
            let jsona = JSON.stringify(banana, null, 2);
            
            fs.writeFile('zauzeca.json', jsona, function (err) {
                if (err) throw err;
                console.log("Valjda oke");
              });
            res.json(jsona);    
        }   
    });

    app.get('/zauzeca.json', function(req, res) {
        console.log(req.url);
            res.sendFile(path.join(__dirname, '/zauzeca.json')); 
    });

    //Drugi zadatak, vracanje svih rezervacija//GOTOVO, RADI
    app.get('/svaZauzeca', function(req, res) {
        var zauz = {
             redovna: [],
             vanredna: []
        }
        db.Rezervacija.findAll().then(rezervacije => {
            rezervacije.forEach(function(rezervacija, index) {
                db.Osoblje.findOne({where: {id: rezervacija.osoba}}).then(osoba =>{
                    db.Sala.findOne({where: {id: rezervacija.sala}}).then(sala => {
                        db.Termin.findOne({where: {id: rezervacija.termin}}).then(termin => {
                            if(termin.redovni) {
                                zauz.redovna.push({
                                    dan: termin.dan,
                                    semestar: termin.semestar,
                                    pocetak: termin.pocetak.toString().substring(0, 5),
                                    kraj: termin.kraj.toString().substring(0, 5),
                                    naziv: sala.naziv,
                                    predavac: osoba.ime + ' ' + osoba.prezime
                                });
                            } else {
                                zauz.vanredna.push({
                                    datum: termin.datum,
                                    pocetak: termin.pocetak.toString().substring(0, 5),
                                    kraj: termin.kraj.toString().substring(0, 5),
                                    naziv: sala.naziv,
                                    predavac: osoba.ime + ' ' + osoba.prezime
                                });
                            }
                            if(index == rezervacije.length-1) {
                                //res.writeHead(200, {'Content-Type': 'application/json'});
                                console.log(zauz);
                                console.log(JSON.stringify(zauz));
                                //Vraca string koji cemo pretvoriti nazad u json da dobijemo sta nam treba
                                res.send(JSON.stringify(zauz));
                            }
                        });
                    });
                });
            });
        });
    });


    app.listen(8080);
    


    module.exports = app;
