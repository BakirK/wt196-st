var kalendar = document.getElementsByClassName("kalendar")[0];
var sale = document.getElementsByName("sale")[0];
var periodicna = document.getElementsByName("periodicna")[0];
var pocetak = document.getElementsByName("pocetak")[0];
var kraj = document.getElementsByName("kraj")[0];
var prethodniB = document.getElementsByClassName("bPrethodni")[0];
var sljedeciB = document.getElementsByClassName("bSljedeci")[0];
let slobodneTabele = document.getElementsByClassName("brojTabela");
let osoblje = document.getElementById("osoblje");

//pozovemo jednom na pocetku
/* Kalendar.ucitajPodatke(pocPeriodicni, pocVanredni); */
Kalendar.iscrtajKalendar(kalendar, 0);
for (let i = 0; i < slobodneTabele.length; i++) {
	slobodneTabele[i].addEventListener("click", zauzmiSaluKlik);
}

function obojiSProvjerom() {
	if (popunjenaPolja()) {
		Kalendar.obojiZauzeca(
			kalendar,
			Mjesec.trenutniMjesec(),
			sale.value,
			pocetak.value,
			kraj.value
		);
	}
}

//button clicks
prethodniB.addEventListener("click", function() {
	for (let i = 0; i < slobodneTabele.length; i++) {
		slobodneTabele[i].removeEventListener("click", zauzmiSaluKlik);
	}
	Kalendar.iscrtajKalendar(kalendar, Mjesec.trenutniMjesec() - 1);
	obojiSProvjerom();
	slobodneTabele = document.getElementsByClassName("brojTabela");
	for (let i = 0; i < slobodneTabele.length; i++) {
		slobodneTabele[i].addEventListener("click", zauzmiSaluKlik);
	}
});

sljedeciB.addEventListener("click", function() {
	for (let i = 0; i < slobodneTabele.length; i++) {
		slobodneTabele[i].removeEventListener("click", zauzmiSaluKlik);
	}
	Kalendar.iscrtajKalendar(kalendar, Mjesec.trenutniMjesec() + 1);
	obojiSProvjerom();
	slobodneTabele = document.getElementsByClassName("brojTabela");
	for (let i = 0; i < slobodneTabele.length; i++) {
		slobodneTabele[i].addEventListener("click", zauzmiSaluKlik);
	}
});

//dodamo onChange listenere za sale,periodicna,pocetak i kraj kako je receno u postavci
sale.addEventListener("change", function() {
	obojiSProvjerom();
});

/* //checkbox cemo kasnije
periodicna.addEventListener("change", function(){
    if(pocetak.value.length>0 && kraj.value.length>0)
        Kalendar.obojiZauzeca(kalendar,Mjesec.trenutniMjesec,sale.value,pocetak.value,kraj.value);
});
*/

pocetak.addEventListener("change", function() {
	obojiSProvjerom();
});

kraj.addEventListener("change", function() {
	obojiSProvjerom();
});

function popunjenaPolja() {
	return pocetak.value.length > 0 && kraj.value.length > 0;
}

/* Samo tabele koje imaju broj u sebi */

function zauzmiSaluKlik(ev) {
	let dann = Number(
		ev.currentTarget.getElementsByClassName("broj")[0].innerHTML
	);
	let praviMjesec = Mjesec.trenutniMjesec() + 1;
	let danString = "0" + dann.toString();
	if (danString.length > 2) danString = danString.substr(1, 2);
	let mjString = "0" + praviMjesec;
	if (mjString.length > 2) mjString = mjString.substr(1, 2);

	if (ev.currentTarget.getElementsByClassName("slobodna").length == 1) {
		let odg = confirm("Želite li zauzeti datu salu?");
		if (odg && popunjenaPolja()) {
			console.log(
				"Datum gresni = " + danString + "." + mjString + ".2020"
			);
			//ako bude vec zauzeta, ova metoda će to prepoznati drugim status koodm
			Pozivi.zauzmiSalu(
				kalendar,
				pocetak.value,
				kraj.value,
				sale.value,
				danString + "." + mjString + ".2020",
				periodicna.checked,
				osoblje.value
			);
		}
	} else {
		Kalendar.ispisiKoJeZauzeo(
			pocetak.value,
			kraj.value,
			danString + "." + mjString + ".2020",
			sale.value
		);
	}
}
