Pozivi.dajLokacijeOsoblja();
setInterval(Pozivi.dajLokacijeOsoblja,30000);