

const dugmePrethodni = document.getElementsByClassName("dugmePrethodni")[0];
const dugmeSljedeci = document.getElementsByClassName("dugmeSljedeci")[0];
const galerija = document.getElementsByClassName("gallery")[0];

Pozivi.pocetneSlike();



dugmePrethodni.addEventListener("click",function(){
    Pozivi.dajSlikePrethodni();
});

dugmeSljedeci.addEventListener("click",function(){
    Pozivi.dajSlikeSljedeci();
});