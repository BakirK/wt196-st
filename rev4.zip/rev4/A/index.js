const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const session = require("express-session");
let kalendar = require("./public/js/kalendar.js");
let util = require("./serverUtils.js");
const app = express();
const db = require("./database/db.js");
let config = require("config");

app.use(bodyParser.json());
app.use(express.static("public"));
app.use(
  session({
    secret: "neka tajna sifra",
    resave: true,
    saveUninitialized: true
  })
);

if (config.util.getEnv("NODE_ENV") !== "test") {
  db.sequelize.sync({ force: true }).then(() =>
    util.inicializacija(function() {
      console.log("Kreiranje i popunjavanje tabela gotovo");
    })
  );
}

//rute
app.get("/", function(req, res) {
  res.sendFile(__dirname + "/public/html/pocetna.html");
});

app.get("/zauzeca", function(req, res) {
  util.dajSvaZauzeca(function(zauzeca) {
    res.send(JSON.stringify(zauzeca));
  });
});

app.post("/zauzeca", function(req, res) {
  body = req.body;
  let periodicna = "dan" in body;
  if (!kalendar.validanFormatZauzeca(body)) {
    let er = { error: "Neispravan format zauzeća!" };
    res.send(JSON.stringify(er));
  } else {
    util.dajSvaZauzeca(function(data) {
      let obj = data;
      let json = JSON.stringify(obj);
      let rez = kalendar.jeSlobodna(body, obj);
      if (rez === null) {
        if (periodicna) {
          obj["periodicna"].push(body);
        } else {
          obj["vandredna"].push(body);
        }
        json = JSON.stringify(obj);
        util.dodajZauzece(body, json, function(json) {
          res.send(json);
        });
      } else {
        util.kreirajPorukuOGreski(body, rez["predavac"], json, function(er) {
          res.send(JSON.stringify(er));
        });
      }
    });
  }
});

app.get("/slike", function(req, res) {
  fs.readdir("./images", function(err, files) {
    if (err) {
      throw err;
    }
    if (req.session.brojUcitanih == null) {
      req.session.brojUcitanih = 0;
      req.session.slike = [];
      for (let img of files) {
        req.session.slike.push({ naziv: img });
      }
    }

    let noveSlike = {};
    let index = req.query["i"];
    let j = 0;
    util.ucitajSliku(index, j, noveSlike, req.session.slike, res);
  });
});

app.get("/osoblje", function(req, res) {
  db.osoblje.findAll().then(function(osoblje) {
    let jsonValues = { osoblje: [] };
    osoblje.forEach(osoba => {
      jsonValues["osoblje"].push(osoba);
    });
    res.send(JSON.stringify(jsonValues));
  });
});

app.get("/sale", function(req, res) {
  db.sala
    .findAll({ include: [{ model: db.osoblje, as: "salaOsoblje" }] })
    .then(function(sale) {
      let jsonValues = { sale: [] };
      sale.forEach(sala => {
        jsonValues["sale"].push(sala);
      });
      res.send(JSON.stringify(jsonValues));
    });
});

app.listen(8080);
module.exports = app;
