const fs = require("fs");
const db = require("./database/db.js");

let ServerUtils = (function() {
  function ucitajSliku(index, j, noveSlike, slike, res) {
    if (j == 3) {
      res.send(JSON.stringify(noveSlike));
      return;
    }
    if (index < slike.length) {
      fs.readFile("./images/" + slike[index].naziv, function(err, data) {
        if (err) {
          throw err;
        }
        noveSlike[j.toString()] = data.toString("base64");
        j++;
        index++;
        ucitajSliku(index, j, noveSlike, slike, res);
      });
    } else {
      res.send(JSON.stringify(noveSlike));
      return;
    }
  }

  function dajSvaZauzeca(callback) {
    db.rezervacija
      .findAll({
        include: [
          { model: db.sala, as: "rezervacijaSala" },
          { model: db.termin, as: "rezervacijaTermin" },
          { model: db.osoblje, as: "rezervacijaOsoblje" }
        ]
      })
      .then(function(data) {
        let zauzeca = { periodicna: [], vandredna: [] };
        data.forEach(item => {
          let zauzecejson = {};
          zauzecejson["pocetak"] = item
            .get()
            ["rezervacijaTermin"].get()
            ["pocetak"].slice(0, -3);
          zauzecejson["kraj"] = item
            .get()
            ["rezervacijaTermin"].get()
            ["kraj"].slice(0, -3);
          zauzecejson["naziv"] = item.get()["rezervacijaSala"].get()["naziv"];
          zauzecejson["predavac"] =
            item.get()["rezervacijaOsoblje"].get()["ime"] +
            " " +
            item.get()["rezervacijaOsoblje"].get()["prezime"];

          if (item.get()["rezervacijaTermin"].get()["redovni"] == true) {
            //periodicna
            zauzecejson["dan"] = item.get()["rezervacijaTermin"].get()["dan"];
            zauzecejson["semestar"] = item.get()["rezervacijaTermin"].get()[
              "semestar"
            ];
            zauzeca["periodicna"].push(zauzecejson);
          } else {
            //vandredna
            zauzecejson["datum"] = item.get()["rezervacijaTermin"].get()[
              "datum"
            ];
            zauzeca["vandredna"].push(zauzecejson);
          }
        });
        callback(zauzeca);
      });
  }

  function dodajZauzece(zauzece, zauzeca, callback) {
    //dodaj zauzece u bazu
    let imePrezime = zauzece["predavac"].split(" ");
    let osoba = { ime: imePrezime[0], prezime: imePrezime[1] };

    let sala = { naziv: zauzece["naziv"] };

    let periodicna = "dan" in zauzece;
    let dan = periodicna ? zauzece["dan"] : null;
    let datum = periodicna ? null : zauzece["datum"];
    let semestar = periodicna ? zauzece["semestar"] : null;

    let termin = {
      redovni: periodicna,
      dan: dan,
      datum: datum,
      semestar: semestar,
      pocetak: zauzece["pocetak"],
      kraj: zauzece["kraj"]
    };

    let promises = [];
    promises.push(db.termin.create(termin));
    promises.push(db.sala.findOrCreate({ where: sala }));
    promises.push(db.osoblje.findOrCreate({ where: osoba }));
    promises.push(db.rezervacija.create({}));
    Promise.all(promises)
      .then(function(result) {
        result[0].setRezervacija(result[3]);
        result[1][0].addRezervacije([result[3]]);
        result[2][0].addRezervacije([result[3]]);
        callback(zauzeca);
      })
      .catch(function(err) {
        console.log("Problem pri dodavanju" + err);
      });
  }

  function kreirajPorukuOGreski(body, predavac, json, callback) {
    let msg;
    let periodicna = "dan" in body;
    if (periodicna == true) {
      let dan = body["dan"];
      let porukeDan = [
        "svaki ponedjeljak",
        "svaki utorak",
        "svaku srijedu",
        "svaki cetvrtak",
        "svaki petak",
        "svaku subotu",
        "svaku nedjelju"
      ];
      let porukeSem = ["ljetnom", "zimskom"];
      let sem = body["semestar"] == "ljetni" ? porukeSem[0] : porukeSem[1];
      msg = "Nije moguće rezervisati salu "
        .concat(body["naziv"])
        .concat(" za ")
        .concat(porukeDan[dan])
        .concat("u ")
        .concat(sem)
        .concat(" semestru i termin od ")
        .concat(body["pocetak"])
        .concat(" do ")
        .concat(body["kraj"])
        .concat("!");
    } else {
      let datum = body["datum"];
      msg = "Nije moguće rezervisati salu "
        .concat(body["naziv"])
        .concat(" za navedeni datum ")
        .concat(datum)
        .concat(" i termin od ")
        .concat(body["pocetak"])
        .concat(" do ")
        .concat(body["kraj"])
        .concat("!");
    }

    msg = msg.concat(" Rezervaciju je već napravio/la ").concat(predavac + ".");
    let er = {
      error: msg.toString(),
      zauzeca: JSON.parse(json)
    };

    callback(er);
  }

  function inicializacija(callback) {
    let promises = [];
    promises.push(
      db.osoblje.findOrCreate({
        where: { ime: "Neko", prezime: "Nekić", uloga: "profesor" }
      })
    );
    promises.push(
      db.osoblje.findOrCreate({
        where: { ime: "Drugi", prezime: "Neko", uloga: "asistent" }
      })
    );
    promises.push(
      db.osoblje.findOrCreate({
        where: { ime: "Test", prezime: "Test", uloga: "asistent" }
      })
    );

    promises.push(
      db.sala.findOrCreate({
        where: { naziv: "1-11" }
      })
    );
    promises.push(
      db.sala.findOrCreate({
        where: { naziv: "1-15" }
      })
    );
    promises.push(
      db.termin.findOrCreate({
        where: {
          redovni: false,
          dan: null,
          datum: "01.01.2020",
          semestar: null,
          pocetak: "12:00",
          kraj: "13:00"
        }
      })
    );
    promises.push(
      db.termin.findOrCreate({
        where: {
          redovni: true,
          dan: 0,
          datum: null,
          semestar: "zimski",
          pocetak: "13:00",
          kraj: "14:00"
        }
      })
    );
    promises.push(
      db.rezervacija.findOrCreate({
        where: { id: 1 }
      })
    );
    promises.push(
      db.rezervacija.findOrCreate({
        where: { id: 2 }
      })
    );
    Promise.all(promises)
      .then(function(dodano) {
        dodano[0][0].setSala(dodano[3][0]);
        dodano[1][0].setSala(dodano[4][0]);
        dodano[5][0].setRezervacija(dodano[7][0]);
        dodano[6][0].setRezervacija(dodano[8][0]);
        dodano[3][0].addRezervacije([dodano[7][0]]);
        dodano[3][0].addRezervacije([dodano[8][0]]);
        dodano[0][0].addRezervacije([dodano[7][0]]);
        dodano[2][0].addRezervacije([dodano[8][0]]);
      })
      .then(callback)
      .catch(function(err) {
        console.log("Opet neki problem " + err);
      });
  }

  return {
    ucitajSliku: ucitajSliku,
    dajSvaZauzeca: dajSvaZauzeca,
    dodajZauzece: dodajZauzece,
    kreirajPorukuOGreski: kreirajPorukuOGreski,
    inicializacija: inicializacija
  };
})();

try {
  exports.ucitajSliku = ServerUtils.ucitajSliku;
  exports.dajSvaZauzeca = ServerUtils.dajSvaZauzeca;
  exports.dodajZauzece = ServerUtils.dodajZauzece;
  exports.kreirajPorukuOGreski = ServerUtils.kreirajPorukuOGreski;
  exports.inicializacija = ServerUtils.inicializacija;
} catch (err) {}
