//povezujemo tako sto dodamo u script tag svake od stranica na kojoj se koristi

let Pozivi = (function() {
  function dobaviZauzecaImpl(callback) {
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        callback(ajax.responseText);
      }
    };
    ajax.open("GET", "http://localhost:8080/zauzeca", true);
    ajax.send();
  }

  function izvrsiRezervacijuImpl(
    sala,
    pocetak,
    kraj,
    dan,
    trenutniMjesec,
    periodicna,
    predavac,
    callbackOk,
    callbackErr
  ) {
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        if (!("error" in JSON.parse(ajax.responseText))) {
          callbackOk(JSON.parse(ajax.responseText));
        } else {
          let msg;
          if (periodicna) {
            let datum =
              +dan + "/" + trenutniMjesec + "/" + Kalendar.dajTrenutnuGodinu();
            msg = "Nije moguće rezervisati salu "
              .concat(sala)
              .concat(" za navedeni datum ")
              .concat(datum)
              .concat(" i termin od ")
              .concat(pocetak)
              .concat(" do ")
              .concat(kraj)
              .concat("!")
              .concat(JSON.parse(ajax.responseText)["error"].split("!")[1]);
          } else {
            msg = JSON.parse(ajax.responseText)["error"];
          }
          callbackErr(msg, JSON.parse(ajax.responseText)["zauzeca"]);
        }
      }
    };
    if (periodicna == true) {
      body = {
        dan: Kalendar.dajDanUSedmici(dan, trenutniMjesec),
        semestar: Kalendar.dajSemestar(trenutniMjesec - 1),
        pocetak: pocetak,
        kraj: kraj,
        naziv: sala,
        predavac: predavac
      };
    } else {
      if (parseInt(dan) <= 9 && parseInt(dan) >= 1) {
        dan = "0" + dan;
      }

      if (parseInt(trenutniMjesec) <= 9 && parseInt(trenutniMjesec) >= 0) {
        trenutniMjesec = "0" + trenutniMjesec;
      }
      body = {
        datum: dan + "." + trenutniMjesec + "." + Kalendar.dajTrenutnuGodinu(),
        pocetak: pocetak,
        kraj: kraj,
        naziv: sala,
        predavac: predavac
      };
    }
    ajax.open("POST", "http://localhost:8080/zauzeca", true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify(body));
  }

  function dobaviSlikeImpl(callback, index) {
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        callback(JSON.parse(ajax.responseText));
      }
    };
    index = encodeURIComponent(index);
    ajax.open("GET", "http://localhost:8080/slike?i=" + index, true);
    ajax.send();
  }

  function dobaviOsobljeImpl(callback) {
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        let jsonValues = {};
        let i = 0;
        JSON.parse(ajax.responseText)["osoblje"].forEach(osoba => {
          jsonValues[i++] = osoba.ime + " " + osoba.prezime;
        });
        callback(jsonValues);
      }
    };
    ajax.open("GET", "http://localhost:8080/osoblje", true);
    ajax.send();
  }

  function dobaviSaleImpl(callback) {
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        let jsonValues = {};
        let i = 0;
        JSON.parse(ajax.responseText)["sale"].forEach(sala => {
          jsonValues[i++] = sala.naziv;
        });
        callback(jsonValues);
      }
    };
    ajax.open("GET", "http://localhost:8080/sale", true);
    ajax.send();
  }

  return {
    dobaviZauzeca: dobaviZauzecaImpl,
    izvrsiRezervaciju: izvrsiRezervacijuImpl,
    dobaviSlike: dobaviSlikeImpl,
    dobaviOsoblje: dobaviOsobljeImpl,
    dobaviSale: dobaviSaleImpl
  };
})();
