let ucitanoOsoblje = [];

function nacrtajTabelu() {
  let sadrzaj = document.getElementsByClassName("sadrzaj")[0];
  let tbl = document.getElementById("tabela");
  if (tbl != null) {
    tbl.remove();
  }
  tbl = document.createElement("table");
  tbl.id = "tabela";
  tbl.classList.add("tabelaSala");
  var thead = document.createElement("tr");
  let h1 = document.createElement("th");
  h1.appendChild(document.createTextNode("Osoba"));
  thead.appendChild(h1);
  h1 = document.createElement("th");
  h1.appendChild(document.createTextNode("Sala"));
  thead.appendChild(h1);

  tbl.appendChild(thead);
  for (let el of ucitanoOsoblje) {
    let tr = document.createElement("tr");
    let td = document.createElement("td");
    td.appendChild(document.createTextNode(el["osoba"]));
    tr.appendChild(td);
    td.classList.add("sala");
    td = document.createElement("td");
    td.appendChild(document.createTextNode(el["naziv"]));
    td.classList.add("sala");
    tr.appendChild(td);
    tbl.appendChild(tr);
  }
  sadrzaj.appendChild(tbl);
}

function trenutno(zauzece) {
  let trenutniDatum = new Date();
  let dan = Kalendar.dajDanUSedmici(
    trenutniDatum.getDate(),
    trenutniDatum.getMonth() + 1
  );
  let datum = Kalendar.dajStringIzDatuma(
    trenutniDatum.getDate(),
    trenutniDatum.getMonth()
  ).replace(/\//g, ".");
  let semestar = Kalendar.dajSemestar(trenutniDatum.getMonth());
  let sati = trenutniDatum.getHours().toString();
  let min = trenutniDatum.getMinutes().toString();
  sati = sati.length > 1 ? sati : "0" + sati;
  min = min.length > 1 ? min : "0" + min;
  let vrijeme = sati + ":" + min;
  if (
    !(
      Kalendar.dajVrijeme(zauzece["pocetak"]) <= Kalendar.dajVrijeme(vrijeme) &&
      Kalendar.dajVrijeme(vrijeme) <= Kalendar.dajVrijeme(zauzece["kraj"])
    )
  )
    return false;

  if ("dan" in zauzece) {
    return dan === zauzece["dan"] && semestar === zauzece["semestar"];
  } else {
    return datum === zauzece["datum"];
  }
}

function azurirajZauzeca(zauzeca) {
  zauzeca = JSON.parse(zauzeca);
  if (
    typeof zauzeca["periodicna"] !== "undefined" &&
    typeof zauzeca["vandredna"] !== "undefined"
  ) {
    zauzeca["periodicna"] = zauzeca["periodicna"].filter(function(z) {
      return trenutno(z);
    });
    zauzeca["vandredna"] = zauzeca["vandredna"].filter(function(z) {
      return trenutno(z);
    });
    for (let el of ucitanoOsoblje) {
      let rezervacija = zauzeca["periodicna"].find(z => {
        return z["predavac"] === el["osoba"];
      });
      if (typeof rezervacija === "undefined") {
        rezervacija = zauzeca["vandredna"].find(z => {
          return z["predavac"] === el["osoba"];
        });
      }
      if (typeof rezervacija === "undefined") {
        el["naziv"] = "u kancelariji";
      } else {
        el["naziv"] = rezervacija["naziv"];
      }
    }
  }
  nacrtajTabelu();
}

function ucitajOsoblje(osoblje) {
  for (let key of Object.keys(osoblje)) {
    let el = ucitanoOsoblje.find(e => {
      return e["osoba"] === osoblje[key];
    });

    if (typeof el === "undefined") {
      ucitanoOsoblje.push({ osoba: osoblje[key], naziv: "" });
    }
  }
  Pozivi.dobaviZauzeca(azurirajZauzeca);
}

function refresuj() {
  Pozivi.dobaviOsoblje(ucitajOsoblje);
  setTimeout(refresuj, 30000);
}

function onLoad() {
  refresuj();
}

window.addEventListener("load", onLoad);
