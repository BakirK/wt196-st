let assert = chai.assert;
let expect = chai.expect;
describe("Kalendar", function() {
  before(function() {
    Kalendar.kreirajKalendar();
  });

  describe("Zadatak 1", function() {
    it("Pozivanje obojiZauzeca kada podaci nisu učitani", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 0);
      let zauzeti = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeti.length, 0);
    });
    it("U zauzećima postoje duple vrijednosti za zauzeće istog termina", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      let vandredna = [
        {
          datum: "23.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Miki Maus"
        },
        {
          datum: "23.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Paja Patak"
        }
      ];

      Kalendar.ucitajPodatke([], vandredna);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "12:00",
        "14:00"
      );
      let zauzeti = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeti.length, 1);
    });
    it("U podacima postoji periodično zauzeće za drugi semestar", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      let periodicna = [
        {
          dan: 2,
          semestar: "ljetni",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Lamija Vrnjak"
        }
      ];

      Kalendar.ucitajPodatke(periodicna, []);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "12:00",
        "14:00"
      );
      let zauzeti = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeti.length, 0);
    });
    it("U podacima postoji zauzeće termina ali u drugom mjesecu", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      let vandredna = [
        {
          datum: "23.09.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Miki Maus"
        }
      ];

      Kalendar.ucitajPodatke([], vandredna);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "12:00",
        "14:00"
      );
      let zauzeti = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeti.length, 0);
    });
    it("U podacima svi termini u mjesecu zauzeti", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);

      let periodicna = [
        {
          dan: 0,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Lamija Vrnjak"
        },
        {
          dan: 1,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Lamija Vrnjak"
        },
        {
          dan: 2,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Lamija Vrnjak"
        },
        {
          dan: 3,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Lamija Vrnjak"
        },
        {
          dan: 4,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Lamija Vrnjak"
        },
        {
          dan: 5,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Lamija Vrnjak"
        },
        {
          dan: 6,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Lamija Vrnjak"
        }
      ];

      Kalendar.ucitajPodatke(periodicna, []);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "12:00",
        "14:00"
      );
      let zauzeti = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeti.length, 30);
    });
    it("Dva puta uzastopno pozivanje obojiZauzece", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);

      let periodicna = [
        {
          dan: 0,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Lamija Vrnjak"
        }
      ];

      Kalendar.ucitajPodatke(periodicna, []);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "12:00",
        "14:00"
      );
      let zauzeti1 = document.getElementsByClassName("zauzeta");

      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "12:00",
        "14:00"
      );
      let zauzeti2 = document.getElementsByClassName("zauzeta");
      expect(zauzeti1).to.equal(zauzeti2);
      //assert.equal(zauzeti1, zauzeti2);
    });
    it("Nakon ucitavanja novih podataka zauzeca se mijenjaju", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);

      let periodicna1 = [
        {
          dan: 0,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Lamija Vrnjak"
        }
      ];

      let periodicna2 = [
        {
          dan: 2,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Lamija Vrnjak"
        }
      ];

      Kalendar.ucitajPodatke(periodicna1, []);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "12:00",
        "14:00"
      );
      let zauzeti1 = document.getElementsByClassName("zauzeta");
      zauzeti1 = Array.prototype.slice.call(zauzeti1).map(x => x.innerHTML);

      Kalendar.ucitajPodatke(periodicna2, []);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "12:00",
        "14:00"
      );
      let zauzeti2 = document.getElementsByClassName("zauzeta");
      zauzeti2 = Array.prototype.slice.call(zauzeti2).map(x => x.innerHTML);

      let staroZauzece = zauzeti1.filter(e => zauzeti2.indexOf(e) > -1);
      assert.equal(staroZauzece.length, 0, "stara zauzeca se moraju obrisati");
      expect(zauzeti1).to.not.equal(zauzeti2);
    });
    it("Oboji se ispravno zauzece", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      let periodicna1 = [
        {
          dan: 0,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Lamija Vrnjak"
        }
      ];

      Kalendar.ucitajPodatke(periodicna1, []);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "12:00",
        "14:00"
      );
      let zauzeti1 = document.getElementsByClassName("zauzeta");
      zauzeti1 = Array.prototype.slice.call(zauzeti1).map(x => x.innerHTML);

      let ispravno = ["4", "11", "18", "25"];
      for (let i = 0; i < ispravno.length; i++) {
        assert.equal(zauzeti1[i], ispravno[i]);
      }
      assert.equal(zauzeti1.length, ispravno.length);
    });
    it("1: Poklapanje termina po presjeku, a ne potpuno", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      let vandredna = [
        {
          datum: "23.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Miki Maus"
        }
      ];

      Kalendar.ucitajPodatke([], vandredna);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "12:30",
        "14:30"
      );
      let zauzeti = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeti.length, 1);
      assert.equal(zauzeti[0].innerHTML, "23");
    });
    it("2: Poklapanje termina po presjeku, a ne potpuno ", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      let vandredna = [
        {
          datum: "23.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Miki Maus"
        }
      ];

      Kalendar.ucitajPodatke([], vandredna);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "10:30",
        "15:30"
      );
      let zauzeti = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeti.length, 1);
      assert.equal(zauzeti[0].innerHTML, "23");
    });
    it("3: Poklapanje termina po presjeku, a ne potpuno ", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      let vandredna = [
        {
          datum: "23.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Miki Maus"
        }
      ];

      Kalendar.ucitajPodatke([], vandredna);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "12:30",
        "13:30"
      );
      let zauzeti = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeti.length, 1);
      assert.equal(zauzeti[0].innerHTML, "23");
    });
    it("4: Poklapanje termina po presjeku, a ne potpuno ", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      let vandredna = [
        {
          datum: "23.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Miki Maus"
        }
      ];

      Kalendar.ucitajPodatke([], vandredna);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "10:30",
        "12:30"
      );
      let zauzeti = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeti.length, 1);
      assert.equal(zauzeti[0].innerHTML, "23");
    });
    it("Termin pocinje odmah kad se drugi zavrsava - ok je", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      let vandredna = [
        {
          datum: "23.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Miki Maus"
        }
      ];

      Kalendar.ucitajPodatke([], vandredna);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "14:00",
        "15:30"
      );
      let zauzeti = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeti.length, 0);
    });
    it("Medju podacima za ucitavanje ima neispravan datum", function() {
      let vandredna = [
        {
          datum: "35.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Miki Maus"
        }
      ];

      Kalendar.ucitajPodatke([], vandredna);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "14:00",
        "15:30"
      );
      let zauzeti = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeti.length, 0);
    });
    it("Medju podacima za ucitavanje ima neispravna godina", function() {
      let vandredna = [
        {
          datum: "14.11.2020",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Miki Maus"
        }
      ];

      Kalendar.ucitajPodatke([], vandredna);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "14:00",
        "15:30"
      );
      let zauzeti = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeti.length, 0);
    });
    it("Medju podacima za ucitavanje ima neispravno vrijeme", function() {
      let vandredna = [
        {
          datum: "17.11.2019",
          pocetak: "12:00",
          kraj: "75:17",
          naziv: "0-02",
          predavac: "Miki Maus"
        }
      ];

      Kalendar.ucitajPodatke([], vandredna);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "14:00",
        "15:30"
      );
      let zauzeti = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeti.length, 0);
    });
    it("Medju podacima za ucitavanje ima neispravan dan", function() {
      let periodicna = [
        {
          dan: 8,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Lamija Vrnjak"
        }
      ];

      Kalendar.ucitajPodatke(periodicna, []);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "14:00",
        "15:30"
      );
      let zauzeti = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeti.length, 0);
    });
    it("Medju podacima za ucitavanje ima neispravan semestar", function() {
      let periodicna = [
        {
          dan: 2,
          semestar: "neispravno",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "0-02",
          predavac: "Lamija Vrnjak"
        }
      ];

      Kalendar.ucitajPodatke(periodicna, []);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "14:00",
        "15:30"
      );
      let zauzeti = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeti.length, 0);
    });
    it("Medju podacima za ucitavanje pocetak je poslije kraja", function() {
      let periodicna = [
        {
          dan: 2,
          semestar: "neispravno",
          pocetak: "12:00",
          kraj: "11:00",
          naziv: "0-02",
          predavac: "Lamija Vrnjak"
        }
      ];

      Kalendar.ucitajPodatke(periodicna, []);
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        10,
        "0-02",
        "14:00",
        "15:30"
      );
      let zauzeti = document.getElementsByClassName("zauzeta");
      assert.equal(zauzeti.length, 0);
    });
  });

  describe("Zadatak 2", function() {
    it("Pozivanje iscrtajKalendar za mjesec sa 30 dana", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      let dani = document.getElementsByClassName("nijeUMjesecu");
      assert.equal(42 - dani.length, 30, "očekivano je da se prikaže 30 dana");
    });
    it("Pozivanje iscrtajKalendar za mjesec sa 31 dan", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 11);
      let dani = document.getElementsByClassName("nijeUMjesecu");
      assert.equal(42 - dani.length, 31, "očekivano je da se prikaže 31 dana");
    });
    it("Pozivanje iscrtajKalendar za trenutni mjesec", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      let mjesec = document.getElementsByClassName("mjesec")[0];
      let dani = mjesec.getElementsByTagName("td");
      let prviDan = Kalendar.prviDanUMjesecu();
      assert.equal(dani[prviDan].classList.contains("nijeUMjesecu"), false);
      assert.equal(4, prviDan, "očekivano je da je 1. dan u petak");
    });
    it("Pozivanje iscrtajKalendar za trenutni mjesec", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 10);
      let mjesec = document.getElementsByClassName("mjesec")[0];
      let dani = mjesec.getElementsByTagName("td");
      let zadnjiDan = Kalendar.zadnjiDanUMjesecu();
      assert.equal(dani[zadnjiDan].classList.contains("nijeUMjesecu"), false);
      assert.equal(5, zadnjiDan, "očekivano je da je 30. dan u subotu");
    });
    it("Pozivanje iscrtajKalendar za januar:", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 0);
      let mjesec = document.getElementsByClassName("mjesec")[0];
      let dani = mjesec.getElementsByTagName("td");
      let j = 1;
      for (let i = 0; i < 42; i++) {
        if (!dani[i].classList.contains("nijeUMjesecu")) {
          assert.equal(j, parseInt(dani[j].innerHTML), "ocekivano " + j);
          j++;
        }
      }
      assert.equal(31, Kalendar.brojDanaUMjesecu(0));
      assert.equal(1, Kalendar.prviDanUMjesecu());
    });
    it("Prelazak na sljedeci mjesec", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 0);
      let zadnjiDan = Kalendar.zadnjiDanUMjesecu();
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 1);
      let prviDan = Kalendar.prviDanUMjesecu();
      assert.equal(zadnjiDan + 1, prviDan);
    });
    it("Prelazak na prethodni mjesec", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 2);
      let prviDan = Kalendar.prviDanUMjesecu();
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 1);
      let zadnjiDan = Kalendar.zadnjiDanUMjesecu();
      assert.equal(zadnjiDan + 1, prviDan);
    });
    it("Nacrtan je kalendar", function() {
      Kalendar.iscrtajKalendar(document.getElementById("kalendar"), 2);
      let dani = document.getElementsByTagName("td");
      assert.equal(dani.length > 0, true);
      let neprikazani = document.getElementsByClassName("nijeUMjesecu");
      assert.equal(neprikazani.length < dani.length, true);
    });
  });
});
