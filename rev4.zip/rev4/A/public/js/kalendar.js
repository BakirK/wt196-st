let Kalendar = (function() {
  let kalendarElement;
  let filtrirano = false;
  let trenutniMjesec;
  let trenutnaGodina = new Date().getFullYear();
  let imenaMjeseci = [
    "Januar",
    "Februar",
    "Mart",
    "April",
    "Maj",
    "Jun",
    "Jul",
    "Avgust",
    "Septembar",
    "Oktobar",
    "Novembar",
    "Decembar"
  ];
  let imenaDana = ["pon", "uto", "sri", "cet", "pet", "sub", "ned"];

  let ucitanePeriodicne = [];
  let ucitaneVandredne = [];

  function jeSlobodnaImpl(rezervacijaJson, zauzeca) {
    periodicne = zauzeca["periodicna"];
    vandredne = zauzeca["vandredna"];
    periodicna = "dan" in rezervacijaJson;
    if (periodicna == true) {
      for (let rez of periodicne) {
        if (
          rez["dan"] == rezervacijaJson["dan"] &&
          rez["semestar"] === rezervacijaJson["semestar"] &&
          !nemaPresjek(
            rez["pocetak"],
            rez["kraj"],
            rezervacijaJson["pocetak"],
            rezervacijaJson["kraj"]
          ) &&
          rez["naziv"] == rezervacijaJson["naziv"]
        ) {
          return rez;
        }
      }

      for (let rez of vandredne) {
        let d = dajDatumIzStringa(rez["datum"]);
        let dan = dajDanUSedmiciImpl(d.getDate(), d.getMonth() + 1);
        let god = d.getFullYear();
        if (
          god === trenutnaGodina &&
          dan === rezervacijaJson["dan"] &&
          dajSemestar(d.getMonth()) === rezervacijaJson["semestar"] &&
          !nemaPresjek(
            rez["pocetak"],
            rez["kraj"],
            rezervacijaJson["pocetak"],
            rezervacijaJson["kraj"]
          ) &&
          rez["naziv"] == rezervacijaJson["naziv"]
        )
          return rez;
      }
    } else {
      let d = dajDatumIzStringa(rezervacijaJson["datum"]);
      let dan = dajDanUSedmiciImpl(d.getDate(), d.getMonth() + 1);
      let god = d.getFullYear();

      for (let rez of vandredne) {
        if (
          !nemaPresjek(
            rez["pocetak"],
            rez["kraj"],
            rezervacijaJson["pocetak"],
            rezervacijaJson["kraj"]
          ) &&
          rez["datum"] === rezervacijaJson["datum"] &&
          rez["naziv"] === rezervacijaJson["naziv"]
        ) {
          return rez;
        }
      }

      for (let rez of periodicne) {
        if (
          dan === rez["dan"] &&
          dajSemestar(d.getMonth()) === rez["semestar"] &&
          !nemaPresjek(
            rez["pocetak"],
            rez["kraj"],
            rezervacijaJson["pocetak"],
            rezervacijaJson["kraj"]
          ) &&
          rez["naziv"] == rezervacijaJson["naziv"]
        ) {
          return rez;
        }
      }
    }

    return null;
  }

  function validanFormatZauzecaImpl(zauzece) {
    if (!("naziv" in zauzece)) return false;
    if (!("predavac" in zauzece)) return false;
    if (!("pocetak" in zauzece)) return false;
    if (!("kraj" in zauzece)) return false;
    if (
      !validnoVrijeme(zauzece["pocetak"]) ||
      !validnoVrijeme(zauzece["kraj"]) ||
      dajVrijeme(zauzece.pocetak) > dajVrijeme(zauzece.kraj)
    )
      return false;
    if ("dan" in zauzece) {
      if (!("semestar" in zauzece)) return false;
      if (!validanDanUSedmici(zauzece["dan"])) return false;
      if (!validanSemestar(zauzece["semestar"])) return false;
      return Object.keys(zauzece).length == 6;
    } else if ("datum" in zauzece) {
      if (Object.keys(zauzece).length != 5) return false;
      return validanDatum(zauzece["datum"]);
    }
    return false;
  }

  function dajDatumIzStringa(datum) {
    let niz = datum.split(".");
    return new Date(parseInt(niz[2]), parseInt(niz[1]) - 1, parseInt(niz[0]));
  }

  function dajStringIzDatuma(dan, mjesec) {
    let datum = "";
    if (dan < 10) {
      datum += "0";
    }
    datum += dan + "/";
    if (mjesec + 1 < 10) {
      datum += "0";
    }
    mjesec++;
    datum += mjesec + "/" + trenutnaGodina.toString();
    return datum;
  }

  function dajImeDanaImpl(dan, mjesec) {
    return imenaDana[dajDanUSedmiciImpl(dan, mjesec)];
  }

  function dajDanUSedmiciImpl(dan, mjesec) {
    let datum = new Date(trenutnaGodina, mjesec - 1, dan);
    let d = datum.getDay();
    return d >= 1 ? d - 1 : 6;
  }

  function postaviFiltriranoImpl(val) {
    filtrirano = val;
  }

  function jeLiFiltriranoImpl() {
    return filtrirano;
  }

  function oslobodiSve() {
    let tabelaMjesec = document.getElementsByClassName("mjesec")[0];
    let dani = tabelaMjesec.getElementsByTagName("td");

    for (let d of dani) {
      oslobodiSalu(d);
    }
  }

  function dodajKlasu(element, klasa) {
    element.classList.add(klasa);
  }

  function obrisiKlasu(element, klasa) {
    element.classList.remove(klasa);
  }

  function oslobodiSalu(element) {
    if (!element.classList.contains("nijeUMjesecu")) {
      obrisiKlasu(element, "zauzeta");
      dodajKlasu(element, "slobodna");
    }
  }

  function zauzmiSalu(element) {
    if (!element.classList.contains("nijeUMjesecu")) {
      obrisiKlasu(element, "slobodna");
      dodajKlasu(element, "zauzeta");
    }
  }

  function prviDanUMjesecu(mjesec) {
    let dan = new Date(trenutnaGodina, mjesec).getDay();
    dan--;
    if (dan == -1) {
      dan = 6;
    }

    return dan;
  }

  function prviDanUMjesecuImpl() {
    return prviDanUMjesecu(trenutniMjesec);
  }

  function brojDanaUMjesecu(mjesec) {
    return new Date(trenutnaGodina, mjesec + 1, 0).getDate();
  }

  function dajTrenutniSemestar() {
    return dajSemestar(trenutniMjesec);
  }

  function dajSemestar(mjesec) {
    return mjesec >= 1 && mjesec <= 5
      ? "ljetni"
      : mjesec >= 9 || mjesec === 0
      ? "zimski"
      : "";
  }

  function dajSate(vrijeme) {
    return parseInt(vrijeme.substring(0, 2));
  }

  function dajMinute(vrijeme) {
    return parseInt(vrijeme.substring(3, 5));
  }

  function dajVrijeme(vrijeme) {
    return new Date(trenutnaGodina, 1, 1, dajSate(vrijeme), dajMinute(vrijeme));
  }

  function dajTrenutnuGodinuImpl() {
    return trenutnaGodina;
  }

  function nemaPresjek(pocetak1, kraj1, pocetak2, kraj2) {
    let p1 = dajVrijeme(pocetak1);
    let k1 = dajVrijeme(kraj1);
    let p2 = dajVrijeme(pocetak2);
    let k2 = dajVrijeme(kraj2);

    return k2 <= p1 || p2 >= k1; //dopustam da se pocinje u isto vrijeme kad se zavrsava
  }

  function zadnjiDanUMjesecu() {
    let dan =
      (prviDanUMjesecu(trenutniMjesec) + brojDanaUMjesecu(trenutniMjesec) - 1) %
      7;

    return dan;
  }

  function dajTrenutniMjesec() {
    return trenutniMjesec;
  }

  function kreirajKalendarImpl() {
    let tabelaMjesec = document.getElementsByClassName("mjesec")[0];
    let dani = tabelaMjesec.getElementsByTagName("td");

    let tr = document.createElement("TR");
    for (let i = 0; i < 7; i++) {
      var th = document.createElement("TH");
      th.classList.add("dani");
      th.appendChild(document.createTextNode(imenaDana[i]));
      tr.appendChild(th);
    }
    tabelaMjesec.appendChild(tr);

    for (let i = 0; i < 6; i++) {
      let tr = document.createElement("TR");
      tr.classList.add("sedmica");
      if (i != 1) tr.classList.add("sakrivena"); //jedna nije skrivena
      for (let j = 0; j < 7; j++) {
        let td = document.createElement("TD");
        tr.appendChild(td);
      }
      tabelaMjesec.appendChild(tr);
    }
  }

  function validnoVrijeme(vrijeme) {
    let regex = /^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/;
    return vrijeme.match(regex);
  }

  function validanSemestar(semestar) {
    return semestar === "ljetni" || semestar === "zimski";
  }

  function validanDatum(datum) {
    let regex = /^([0-2][0-9]|(3)[0-1])(\.)(((0)[0-9])|((1)[0-2]))(\.)\d{4}$/;
    let d = dajDatumIzStringa(datum);
    let curr_date = d.getDate();
    let curr_month = d.getMonth() + 1;
    let curr_year = d.getFullYear();
    let n = datum.split(".");
    return (
      datum.match(regex) &&
      parseInt(n[0]) == curr_date &&
      parseInt(n[1]) == curr_month &&
      parseInt(n[2]) == curr_year
    );
  }

  function validanDanUSedmici(dan) {
    return dan >= 0 && dan <= 6;
  }

  //.............funkcije predvidjene zadatkom.............
  function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj) {
    kalendarElement = kalendarRef;
    trenutniMjesec = mjesec;
    let tabelaMjesec = document.getElementsByClassName("mjesec")[0];
    let dani = tabelaMjesec.getElementsByTagName("td");
    oslobodiSve();

    ucitanePeriodicne
      .filter(rezervacija => {
        return (
          rezervacija.semestar == dajTrenutniSemestar() &&
          rezervacija.naziv == sala &&
          !nemaPresjek(pocetak, kraj, rezervacija.pocetak, rezervacija.kraj)
        );
      })
      .forEach(rezervacija => {
        let i;
        for (i = 0; i < dani.length; i++) {
          if (i % 7 == rezervacija.dan) {
            zauzmiSalu(dani[i]);
          }
        }
      });

    ucitaneVandredne
      .filter(rezervacija => {
        let tmpMjesec = dajDatumIzStringa(rezervacija.datum).getMonth();
        let tmpGodina = dajDatumIzStringa(rezervacija.datum).getFullYear();
        return (
          tmpMjesec == mjesec &&
          tmpGodina == trenutnaGodina &&
          rezervacija.naziv == sala &&
          !nemaPresjek(pocetak, kraj, rezervacija.pocetak, rezervacija.kraj)
        );
      })
      .forEach(rezervacija => {
        let i =
          dajDatumIzStringa(rezervacija.datum).getDate() +
          prviDanUMjesecu(mjesec) -
          1;
        zauzmiSalu(dani[i]);
      });
  }
  function ucitajPodatkeImpl(periodicna, vandredna) {
    oslobodiSve();
    ucitanePeriodicne = periodicna.filter(rez => {
      return validanFormatZauzecaImpl(rez);
    });
    ucitaneVandredne = vandredna.filter(rez => {
      return validanFormatZauzecaImpl(rez);
    });
  }

  function iscrtajKalendarImpl(kalendarRef, mjesec) {
    kalendarElement = kalendarRef;
    trenutniMjesec = mjesec;
    let prviDan = prviDanUMjesecu(mjesec);
    let brojDana = brojDanaUMjesecu(mjesec);
    let dan = 1;

    let nazivMjeseca = kalendarElement.getElementsByTagName("h3")[0];
    nazivMjeseca.innerHTML = imenaMjeseci[mjesec];
    let tabelaMjesec = document.getElementsByClassName("mjesec")[0];
    let dani = tabelaMjesec.getElementsByTagName("td");

    for (let i = 0; i < dani.length; i++) {
      obrisiKlasu(dani[i], "nijeUMjesecu");
      obrisiKlasu(dani[i], "zauzeta");
      obrisiKlasu(dani[i], "slobodna");
      if (i < prviDan || i > brojDana + prviDan - 1) {
        dani[i].innerHTML = "x";
        dodajKlasu(dani[i], "nijeUMjesecu");
      } else {
        dani[i].innerHTML = dan;
        dan++;
        oslobodiSalu(dani[i]);
      }
    }
  }
  return {
    obojiZauzeca: obojiZauzecaImpl,
    ucitajPodatke: ucitajPodatkeImpl,
    iscrtajKalendar: iscrtajKalendarImpl,
    kreirajKalendar: kreirajKalendarImpl,
    zadnjiDanUMjesecu: zadnjiDanUMjesecu,
    prviDanUMjesecu: prviDanUMjesecuImpl,
    brojDanaUMjesecu: brojDanaUMjesecu,
    postaviFiltrirano: postaviFiltriranoImpl,
    jeLiFiltrirano: jeLiFiltriranoImpl,
    dajImeDana: dajImeDanaImpl,
    dajTrenutniSemestar: dajTrenutniSemestar,
    dajDanUSedmici: dajDanUSedmiciImpl,
    jeSlobodna: jeSlobodnaImpl,
    dajSemestar: dajSemestar,
    dajStringIzDatuma: dajStringIzDatuma,
    dajTrenutniMjesec: dajTrenutniMjesec,
    dajTrenutnuGodinu: dajTrenutnuGodinuImpl,
    validanFormatZauzeca: validanFormatZauzecaImpl,
    dajVrijeme: dajVrijeme
  };
})();

try {
  exports.jeSlobodna = Kalendar.jeSlobodna;
  exports.dajTrenutniMjesec = Kalendar.dajTrenutniMjesec;
  exports.dajStringIzDatuma = Kalendar.dajStringIzDatuma;
  exports.validanFormatZauzeca = Kalendar.validanFormatZauzeca;
  exports.dajVrijeme = Kalendar.dajVrijeme;
} catch (err) {}
