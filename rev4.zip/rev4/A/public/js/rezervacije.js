let kalendarElement = document.getElementsByClassName("kalendar")[0];
let trenutniMjesec = new Date().getMonth();
let prethodni = document.getElementById("prethodni");
let sljedeci = document.getElementById("sljedeci");
let listaSala = document.getElementById("listaSala");
let pocetak = document.getElementById("pocetak");
let kraj = document.getElementById("kraj");
let periodicna = document.getElementById("periodicna");

function crtaj(delta) {
  if (
    (!(trenutniMjesec == 0 && delta == -1) &&
      !(trenutniMjesec == 11 && delta == 1)) ||
    delta === 0
  ) {
    trenutniMjesec += delta;
    Kalendar.iscrtajKalendar(kalendarElement, trenutniMjesec);
  }
  oboji();
}

function oboji() {
  Kalendar.postaviFiltrirano(false);
  let listaSala = document.getElementById("listaSala");
  let odabranaSala = listaSala.options[listaSala.selectedIndex].text;
  let pocetak = document.getElementById("pocetak").value;
  let kraj = document.getElementById("kraj").value;

  if (pocetak !== "" && kraj !== "") {
    Kalendar.postaviFiltrirano(true);
    Kalendar.obojiZauzeca(
      kalendarElement,
      trenutniMjesec,
      odabranaSala,
      pocetak,
      kraj
    );
  }
}

function rezervisi(celija) {
  if (
    //celija.classList.contains("zauzeta") ||
    celija.classList.contains("nijeUMjesecu")
  )
    return;

  if (Kalendar.jeLiFiltrirano() == true) {
    let odabranaSala = listaSala.options[listaSala.selectedIndex].text;
    let jePeriodicna = periodicna.checked;
    let dan = celija.innerText;
    let listaPredacacva = document.getElementById("osoba");
    let predavac = listaPredacacva.options[listaPredacacva.selectedIndex].text;
    let semestar =
      Kalendar.dajTrenutniSemestar() == "zimski" ? "zimskom" : "ljetnom";

    if (jePeriodicna && Kalendar.dajTrenutniSemestar() === "") {
      alert("Nije moguće napraviti periodičnu rezervaciju u ovom mjesecu");
      return;
    }

    if (Kalendar.dajVrijeme(pocetak.value) >= Kalendar.dajVrijeme(kraj.value)) {
      alert("Neispravan format zauzeća, početak mora biti prije kraja");
      return;
    }

    let poruke = [
      "svaki ponedjeljak",
      "svaki utorak",
      "svaku srijedu",
      "svaki cetvrtak",
      "svaki petak",
      "svaku subotu",
      "svaku nedjelju"
    ];

    specificniTekst = jePeriodicna
      ? poruke[Kalendar.dajDanUSedmici(dan, trenutniMjesec + 1)] +
        " u " +
        semestar +
        " semestru"
      : dan + "/" + (trenutniMjesec + 1) + "/" + Kalendar.dajTrenutnuGodinu();

    let tekst =
      "Želite li rezervisati salu " +
      odabranaSala +
      " za " +
      specificniTekst +
      "?";
    let ok = confirm(tekst);
    if (ok == true) {
      Pozivi.izvrsiRezervaciju(
        odabranaSala,
        pocetak.value,
        kraj.value,
        dan,
        trenutniMjesec + 1,
        jePeriodicna,
        predavac,
        refresujPodatke,
        prikaziGresku
      );
    }
  }
}

function refresujPodatke(zauzeca) {
  Kalendar.ucitajPodatke(zauzeca["periodicna"], zauzeca["vandredna"]);
  oboji();
}

function prikaziGresku(errorMsg, zauzeca) {
  refresujPodatke(zauzeca);
  alert(errorMsg);
}

function ucitaj(zauzeca) {
  zauzeca = JSON.parse(zauzeca);
  Kalendar.kreirajKalendar();
  Kalendar.ucitajPodatke(zauzeca["periodicna"], zauzeca["vandredna"]);
  Kalendar.iscrtajKalendar(kalendarElement, trenutniMjesec);
  let celije = document.getElementsByTagName("td");
  for (let i = 1; i < celije.length; i++) {
    celije
      .item(i)
      .addEventListener("click", rezervisi.bind(null, celije.item(i)));
  }

  Pozivi.dobaviOsoblje(popuniOsoblje);
}

function popuniOsoblje(osoblje) {
  let select = document.getElementById("osoba");
  for (index in osoblje) {
    select.options[select.options.length] = new Option(osoblje[index], index);
  }

  Pozivi.dobaviSale(popuniSale);
}

function popuniSale(sale) {
  let select = document.getElementById("listaSala");
  let dalje = false;
  for (index in sale) {
    for (let item of select.options) {
      if (item.innerText === sale[index]) {
        dalje = true;
        break;
      }
    }
    if (dalje) {
      dalje = false;
      continue;
    }
    select.options[select.options.length] = new Option(sale[index], index);
  }
}

function onLoad() {
  prethodni.addEventListener("click", crtaj.bind(null, -1));
  sljedeci.addEventListener("click", crtaj.bind(null, 1));
  pocetak.addEventListener("change", oboji);
  kraj.addEventListener("change", oboji);
  listaSala.addEventListener("change", oboji);
  Kalendar.postaviFiltrirano(false);
  Pozivi.dobaviZauzeca(ucitaj);
}

window.addEventListener("load", onLoad);
