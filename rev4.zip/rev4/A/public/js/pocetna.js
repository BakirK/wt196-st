function prikaziSliku(image64) {
  let grid = document.getElementsByClassName("grid")[0];
  let img = document.createElement("img");
  img.src = "data:image/png;base64,".concat(image64);
  grid.appendChild(img);
}

function obrisiSlike() {
  let grid = document.getElementsByClassName("grid")[0];
  while (grid.firstChild) {
    grid.removeChild(grid.firstChild);
  }
}

function prikaziTri(delta) {
  obrisiSlike();
  let s = JSON.parse(sessionStorage.getItem("slike"));
  let brojUcitanih = parseInt(sessionStorage.getItem("brojUcitanih"));
  let prikazanaTrojka = parseInt(sessionStorage.getItem("prikazanaTrojka"));

  prikazanaTrojka += delta;
  sessionStorage["prikazanaTrojka"] = prikazanaTrojka.toString();
  for (
    let i = prikazanaTrojka * 3;
    i < prikazanaTrojka * 3 + 3 && i < brojUcitanih;
    i++
  ) {
    prikaziSliku(s[i.toString()]);
  }
}

function prikazi(slike) {
  let noveSlike = Object.keys(slike);
  if (noveSlike.length < 3) sessionStorage["sveUcitane"] = "true";
  if (noveSlike.length == 0) return;

  obrisiSlike();
  let brojUcitanih = parseInt(sessionStorage.getItem("brojUcitanih"));
  let prikazanaTrojka = parseInt(sessionStorage.getItem("prikazanaTrojka"));

  for (let rb of noveSlike) {
    let s = JSON.parse(sessionStorage.getItem("slike"));
    s[(parseInt(rb) + brojUcitanih).toString()] = slike[rb];
    sessionStorage["slike"] = JSON.stringify(s);
    prikaziSliku(slike[rb]);
  }

  brojUcitanih += noveSlike.length;
  prikazanaTrojka++;
  sessionStorage["brojUcitanih"] = brojUcitanih.toString();
  sessionStorage["prikazanaTrojka"] = prikazanaTrojka.toString();
}

function sljedece() {
  let prikazanaTrojka = parseInt(sessionStorage.getItem("prikazanaTrojka"));
  let brojUcitanih = parseInt(sessionStorage.getItem("brojUcitanih"));
  let sveUcitane = sessionStorage.getItem("sveUcitane");
  let prikazano = (prikazanaTrojka + 1) * 3 + 1;
  if (
    sveUcitane === "false" &&
    (prikazano >= brojUcitanih || prikazanaTrojka == -1)
  ) {
    Pozivi.dobaviSlike(prikazi, prikazano - 1);
  } else if (prikazano <= brojUcitanih) {
    prikaziTri(1);
  } else {
    prikaziTri(0);
  }
}

function ucitajSlike(dugme) {
  let prikazanaTrojka = parseInt(sessionStorage.getItem("prikazanaTrojka"));
  if (dugme == "prethodni" && prikazanaTrojka > 0) {
    prikaziTri(-1);
  } else if (dugme == "sljedeci") {
    sljedece();
  }
}

function onLoad() {
  prethodni.addEventListener("click", ucitajSlike.bind(null, "prethodni"));
  sljedeci.addEventListener("click", ucitajSlike.bind(null, "sljedeci"));
  sessionStorage["slike"] = "{}";
  sessionStorage["brojUcitanih"] = "0";
  sessionStorage["prikazanaTrojka"] = "-1";
  sessionStorage["sveUcitane"] = "false";
  ucitajSlike("sljedeci");
}

window.addEventListener("load", onLoad);
