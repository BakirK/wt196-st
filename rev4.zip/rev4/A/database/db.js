const Sequelize = require("sequelize");
let config = require("config");
const sequelize = new Sequelize(config.get("dbName"), "root", "root", {
  host: "127.0.0.1",
  dialect: "mysql",
  logging: false,
  port: 3308
});
const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

//import modela
db.osoblje = sequelize.import(__dirname + "/model/Osoblje.js");
db.rezervacija = sequelize.import(__dirname + "/model/Rezervacija.js");
db.sala = sequelize.import(__dirname + "/model/Sala.js");
db.termin = sequelize.import(__dirname + "/model/Termin.js");

//relacije
//Osoblje - jedan na više - Rezervacija
db.osoblje.hasMany(db.rezervacija, {
  as: "rezervacije",
  foreignKey: "osoba"
});
db.rezervacija.belongsTo(db.osoblje, {
  as: "rezervacijaOsoblje",
  foreignKey: "osoba"
});

// Rezervacija - jedan na jedan - Termin
db.termin.hasOne(db.rezervacija, {
  as: "rezervacija",
  foreignKey: { name: "termin", unique: true }
});
db.rezervacija.belongsTo(db.termin, {
  as: "rezervacijaTermin",
  foreignKey: "termin"
});

// // Rezervacija - više na jedan - Sala
db.sala.hasMany(db.rezervacija, { as: "rezervacije", foreignKey: "sala" });
db.rezervacija.belongsTo(db.sala, {
  as: "rezervacijaSala",
  foreignKey: "sala"
});

// Sala - jedan na jedan - Osoblje
db.osoblje.hasOne(db.sala, {
  as: "sala",
  foreignKey: "zaduzenaOsoba"
});
db.sala.belongsTo(db.osoblje, {
  as: "salaOsoblje",
  foreignKey: "zaduzenaOsoba"
});

module.exports = db;
