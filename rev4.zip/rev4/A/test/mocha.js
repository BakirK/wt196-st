let chai = require("chai");
let chaiHttp = require("chai-http");
let expect = chai.expect;
let assert = chai.assert;
let server = require("../index.js");
let db = require("../database/db");
let util = require("../serverUtils.js");

chai.use(chaiHttp);

describe("Testovi", function() {
  before(function(done) {
    this.enableTimeouts(false);
    db.sequelize.sync({ force: true }).then(() => util.inicializacija(done));
  });

  // after(function(done) {
  //   this.enableTimeouts(false);
  //   db.sequelize.sync({ force: true }).then(() => done());
  // });

  describe("/get osoblje", function() {
    it("U bazi su tri osobe", function(done) {
      chai
        .request(server)
        .get("/osoblje")
        .end((err, res) => {
          expect(res.text).to.be.a("string");
          expect(Object.keys(JSON.parse(res.text)["osoblje"]).length).to.eql(3);
          done();
        });
    });

    it("U bazi su ispravne osobe", function(done) {
      chai
        .request(server)
        .get("/osoblje")
        .end((err, res) => {
          let osoblje = JSON.parse(res.text)["osoblje"];
          osoblje.sort(function(o1, o2) {
            return o1.ime + " " + o1.prezime < o2.ime + " " + o2.prezime
              ? -1
              : 1;
          });
          expect(osoblje[0]).to.have.property("ime", "Drugi");
          expect(osoblje[0]).to.have.property("prezime", "Neko");
          expect(osoblje[0]).to.have.property("uloga", "asistent");
          expect(osoblje[1]).to.have.property("ime", "Neko");
          expect(osoblje[1]).to.have.property("prezime", "Nekić");
          expect(osoblje[1]).to.have.property("uloga", "profesor");
          expect(osoblje[2]).to.have.property("ime", "Test");
          expect(osoblje[2]).to.have.property("prezime", "Test");
          expect(osoblje[2]).to.have.property("uloga", "asistent");
          done();
        });
    });

    it("Dodavanje osobe", function(done) {
      let osoba = {
        ime: "Lamija",
        prezime: "Vrnjak",
        uloga: "demonstrator"
      };
      db.osoblje.create(osoba).then(o => {
        chai
          .request(server)
          .get("/osoblje")
          .end((err, res) => {
            let osoblje = JSON.parse(res.text)["osoblje"];
            expect(osoblje).to.have.lengthOf(4);
            expect(osoblje[3]).to.have.property("ime", "Lamija");
            expect(osoblje[3]).to.have.property("prezime", "Vrnjak");
            expect(osoblje[3]).to.have.property("uloga", "demonstrator");
            o.destroy();
            done();
          });
      });
    });
  });

  describe("/get sale", function() {
    it("U bazi su dvije sale", function(done) {
      chai
        .request(server)
        .get("/sale")
        .end((err, res) => {
          expect(res.text).to.be.a("string");
          expect(Object.keys(JSON.parse(res.text)["sale"]).length).to.eql(2);
          done();
        });
    });

    it("U bazi su ispravni nazivi sala", function(done) {
      chai
        .request(server)
        .get("/sale")
        .end((err, res) => {
          let sale = JSON.parse(res.text)["sale"];
          //console.log(res.text);
          expect(sale[0]).to.have.property("naziv");
          let naziv = sale[0].naziv;
          expect(naziv).to.be.oneOf(["1-11", "1-15"]);
          naziv = naziv === "1-11" ? "1-15" : "1-11";
          expect(sale[1]).to.have.property("naziv", naziv);
          done();
        });
    });

    it("Sale imaju ispravne zaduzene osobe", function(done) {
      chai
        .request(server)
        .get("/sale")
        .end((err, res) => {
          let sale = JSON.parse(res.text)["sale"];
          expect(sale[0]).to.have.deep.property("salaOsoblje");
          let ime = sale[0].salaOsoblje.ime;
          expect(ime).to.be.oneOf(["Neko", "Drugi"]);
          let prezime = ime === "Neko" ? "Nekić" : "Neko";
          expect(sale[0].salaOsoblje.prezime).to.eql(prezime);
          ime = ime === "Neko" ? "Drugi" : "Neko";
          prezime = ime === "Neko" ? "Nekić" : "Neko";
          expect(sale[1].salaOsoblje).to.have.property("ime", ime);
          expect(sale[1].salaOsoblje).to.have.property("prezime", prezime);
          done();
        });
    });

    it("Dodavanje sale", function(done) {
      let sala = {
        naziv: "S0"
      };
      db.sala.create(sala).then(s => {
        chai
          .request(server)
          .get("/sale")
          .end((err, res) => {
            let sale = JSON.parse(res.text)["sale"];
            expect(sale).to.have.lengthOf(3);
            expect(sale[2]).to.have.property("naziv", "S0");
            s.destroy();
            done();
          });
      });
    });
  });

  describe("/get i /post zauzeća", function() {
    it("U bazi su dva zauzeća", function(done) {
      chai
        .request(server)
        .get("/zauzeca")
        .end((err, res) => {
          let periodicna = JSON.parse(res.text)["periodicna"];
          let vandredna = JSON.parse(res.text)["vandredna"];
          expect(res.text).to.be.a("string");
          expect(Object.keys(JSON.parse(res.text)).length).to.eql(2);
          expect(periodicna).to.have.lengthOf(1);
          expect(vandredna).to.have.lengthOf(1);
          done();
        });
    });

    it("Vrati se ispravan format zauzeca", function(done) {
      chai
        .request(server)
        .get("/zauzeca")
        .end((err, res) => {
          let periodicna = JSON.parse(res.text)["periodicna"];
          let vandredna = JSON.parse(res.text)["vandredna"];
          expect(periodicna).to.be.an.instanceOf(Array);
          expect(vandredna).to.be.an.instanceOf(Array);
          done();
        });
    });

    it("Test ispravnosti prvog zauzeca", function(done) {
      chai
        .request(server)
        .get("/zauzeca")
        .end((err, res) => {
          let periodicna = JSON.parse(res.text)["periodicna"];
          expect(periodicna[0]).to.be.an.instanceOf(Object);
          expect(periodicna[0]).to.have.property("dan", 0);
          expect(periodicna[0]).to.have.property("semestar", "zimski");
          expect(periodicna[0]).to.have.property("predavac", "Test Test");
          expect(periodicna[0]).to.have.property("naziv", "1-11");
          expect(periodicna[0]).to.have.property("pocetak", "13:00");
          expect(periodicna[0]).to.have.property("kraj", "14:00");
          done();
        });
    });

    it("Test ispravnosti drugog zauzeca", function(done) {
      chai
        .request(server)
        .get("/zauzeca")
        .end((err, res) => {
          let vandredna = JSON.parse(res.text)["vandredna"];
          expect(vandredna[0]).to.be.an.instanceOf(Object);
          expect(vandredna[0]).to.have.property("datum", "01.01.2020");
          expect(vandredna[0]).to.have.property("predavac", "Neko Nekić");
          expect(vandredna[0]).to.have.property("naziv", "1-11");
          expect(vandredna[0]).to.have.property("pocetak", "12:00");
          expect(vandredna[0]).to.have.property("kraj", "13:00");
          done();
        });
    });

    it("Ispravno dohvaćanje nakon doavanja zauzeća", function(done) {
      chai
        .request(server)
        .get("/zauzeca")
        .end(function(err, res) {
          let zauzeca = JSON.parse(res.text);
          let stariBrZauzeca =
            zauzeca["periodicna"].length + zauzeca["vandredna"].length;
          chai
            .request(server)
            .post("/zauzeca")
            .send({
              datum: "14.02.2020",
              pocetak: "09:00",
              kraj: "12:00",
              naziv: "MA",
              predavac: "Profesor Profesorković"
            })
            .end(function(err, res) {
              let zauzeca = JSON.parse(res.text);
              let brZauzeca =
                zauzeca["periodicna"].length + zauzeca["vandredna"].length;
              assert.equal(stariBrZauzeca + 1, brZauzeca);
              done();
            });
        });
    });

    it("Test ispravnosti dodanog zauzeca - vandredno", function(done) {
      chai
        .request(server)
        .post("/zauzeca")
        .send({
          datum: "25.02.2020",
          pocetak: "09:00",
          kraj: "12:00",
          naziv: "MA",
          predavac: "Neko Drugi"
        })
        .end(function(err, res) {
          let zauzeca = JSON.parse(res.text);
          let dodano = zauzeca.vandredna[zauzeca.vandredna.length - 1];
          expect(dodano).to.have.property("datum", "25.02.2020");
          expect(dodano).to.have.property("pocetak", "09:00");
          expect(dodano).to.have.property("kraj", "12:00");
          expect(dodano).to.have.property("naziv", "MA");
          expect(dodano).to.have.property("predavac", "Neko Drugi");
          done();
        });
    });

    it("Test ispravnosti dodanog zauzeca - perodicno", function(done) {
      chai
        .request(server)
        .post("/zauzeca")
        .send({
          dan: 2,
          semestar: "zimski",
          pocetak: "09:00",
          kraj: "12:00",
          naziv: "MA",
          predavac: "Miki Maus"
        })
        .end(function(err, res) {
          let zauzeca = JSON.parse(res.text);
          let dodano = zauzeca.periodicna[zauzeca.periodicna.length - 1];
          expect(dodano).to.have.property("dan", 2);
          expect(dodano).to.have.property("pocetak", "09:00");
          expect(dodano).to.have.property("kraj", "12:00");
          expect(dodano).to.have.property("naziv", "MA");
          expect(dodano).to.have.property("predavac", "Miki Maus");
          expect(dodano).to.have.property("semestar", "zimski");
          done();
        });
    });

    it("Dodavanje zauzeca sa salom koje nema u bazi (treba je dodati)", function(done) {
      chai
        .request(server)
        .get("/sale")
        .end((err, res) => {
          let sale = JSON.parse(res.text)["sale"];
          let brSala = sale.length;
          chai
            .request(server)
            .post("/zauzeca")
            .send({
              dan: 3,
              semestar: "zimski",
              pocetak: "09:00",
              kraj: "12:00",
              naziv: "S1",
              predavac: "Neko Nekić"
            })
            .end(function(err, res) {
              chai
                .request(server)
                .get("/sale")
                .end((err, res) => {
                  sale = JSON.parse(res.text)["sale"];
                  expect(sale).to.have.lengthOf(brSala + 1);
                  expect(sale[brSala]).to.have.property("naziv", "S1");
                  done();
                });
            });
        });
    });

    it("Dodavanje zauzeca sa predavačem kojeg nema u bazi (treba ge dodati)", function(done) {
      chai
        .request(server)
        .get("/osoblje")
        .end((err, res) => {
          let osoblje = JSON.parse(res.text)["osoblje"];
          let brOsoba = osoblje.length;
          chai
            .request(server)
            .post("/zauzeca")
            .send({
              dan: 3,
              semestar: "zimski",
              pocetak: "09:00",
              kraj: "12:00",
              naziv: "1-11",
              predavac: "Nepostojeci Predavac"
            })
            .end(function(err, res) {
              chai
                .request(server)
                .get("/osoblje")
                .end((err, res) => {
                  osoblje = JSON.parse(res.text)["osoblje"];
                  expect(osoblje).to.have.lengthOf(brOsoba + 1);
                  expect(osoblje[brOsoba]).to.have.property(
                    "ime",
                    "Nepostojeci"
                  );
                  expect(osoblje[brOsoba]).to.have.property(
                    "prezime",
                    "Predavac"
                  );
                  done();
                });
            });
        });
    });

    it("Dodavanje neispravnog zauzeca (postoji preklapanje)", function(done) {
      chai
        .request(server)
        .post("/zauzeca")
        .send({
          dan: 0,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "15:00",
          naziv: "1-11",
          predavac: "Miki Maus"
        })
        .end(function(err, res) {
          let zauzeca = JSON.parse(res.text);
          expect(zauzeca).to.have.property("error");
          done();
        });
    });

    it("Dodavanje neispravnog zauzeca (postoji preklapanje)", function(done) {
      chai
        .request(server)
        .post("/zauzeca")
        .send({
          datum: "01.01.2020",
          pocetak: "12:30",
          kraj: "14:00",
          naziv: "1-11",
          predavac: "Miki Maus"
        })
        .end(function(err, res) {
          let zauzeca = JSON.parse(res.text);
          expect(zauzeca).to.have.property("error");
          expect(zauzeca["error"]).to.contain("Neko Nekić");
          done();
        });
    });

    it("Dodavanje neispravnog zauzeca (neispravan format zauzeca)", function(done) {
      chai
        .request(server)
        .post("/zauzeca")
        .send({
          dan: 0,
          datum: "14.08.2020",
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "15:00",
          naziv: "1-11",
          predavac: "Miki Maus"
        })
        .end(function(err, res) {
          let zauzeca = JSON.parse(res.text);
          expect(zauzeca).to.have.property("error");
          expect(zauzeca["error"]).to.eql("Neispravan format zauzeća!");
          done();
        });
    });
  });
});
