let Pozivi = (function(){
    let per = [];
    let van = [];
    //var gl = 
    function ucitajJsonPodatkeImpl(){
        var xhr = new XMLHttpRequest();
       xhr.open('GET', "http://localhost:8080/dohvatiPodatke", true);
        xhr.onreadystatechange = function(){
            if(xhr.readyState == 4 && xhr.status == 200)
                {
                    
                    var obj = JSON.parse(this.responseText);
                    Kalendar.ucitajPodatke(obj.periodicna, obj.vanredna);
                   
                    iscrtajKalendar();
                    obojiZauzecaPoziv();
                }
            if(xhr.readyState == 4 && xhr.status == 404)
                alert("ne radi");
        }
       // xhr.open("GET", "http://localhost:8080/dohvatiPodatke", true);
        xhr.send();
    }

    function rezervisiTerminImpl(objekat){
       var xhr1 = new XMLHttpRequest();
       xhr1.open('POST', "http://localhost:8080/unesiPodatke", true);
       xhr1.setRequestHeader("Content-Type", "application/json");
      
       xhr1.send(objekat);
    }

    function rezervisiTerminPeriodicniImpl(objekat){
        var xhr = new XMLHttpRequest();
        xhr.open('POST', "http://localhost:8080/unesiPeriodicno", true);
        xhr.setRequestHeader("Content-Type", "application/json");
        console.log(objekat);
        xhr.send(objekat);
    }

    function ucitajSlikeImpl(element, varijabla){
        var xhr = new XMLHttpRequest();
        var j;
        xhr.open('GET',"http://localhost:8080/dohvatiSlike", true);
        xhr.onreadystatechange = function(){
            if(xhr.readyState == 4 && xhr.status == 200) 
                {
                    var slikaKojuPrikazujem = JSON.parse(this.responseText);
                    var i;
                    var img;
                    var sl;
                    for(i=0; i<3; i++)
                    {
                    if(varijabla == 1)
                    {
                    img = document.getElementsByClassName(element)[i].getElementsByTagName("img")[0];       
                     sl = slikaKojuPrikazujem[`s${i+1}`].data;
                     var x = document.getElementsByClassName("slika");
                        x[1].style.display = "block";
                        x[2].style.display = "block";
                    }
                    if(varijabla == 2)
                    {
                     img = document.getElementsByClassName(element)[i].getElementsByTagName("img")[0];       
                    sl = slikaKojuPrikazujem[`s${i+4}`].data;
                    var x = document.getElementsByClassName("slika");
                        x[1].style.display = "block";
                        x[2].style.display = "block";
                    }
                    if(varijabla == 3)
                    {
                     img = document.getElementsByClassName(element)[i].getElementsByTagName("img")[0];       
                     sl = slikaKojuPrikazujem[`s${i+7}`].data;
                     var x = document.getElementsByClassName("slika");
                        x[1].style.display = "block";
                        x[2].style.display = "block";
                    }
                    if(varijabla == 4)
                    {
                         img = document.getElementsByClassName(element)[i].getElementsByTagName("img")[0];       
                    sl = slikaKojuPrikazujem[`s${10}`].data;
                        var x = document.getElementsByClassName("slika");
                        x[1].style.display = "none";
                        x[2].style.display = "none";
                    }
                    var b64encoded=btoa(new Uint8Array(sl).reduce(function (sl, byte)
                     {
                    return sl + String.fromCharCode(byte);
                    }, ''));
                    var d = "data:image/png;base64,"+b64encoded;
                    img.src = d;
                    }
                }
            if(xhr.readyState == 4 && xhr.status == 404)
                console.log("Slike nisu ucitane.");
        }
        xhr.send();
    } 
    
    return{
        ucitajJsonPodatke : ucitajJsonPodatkeImpl,
        rezervisiTermin : rezervisiTerminImpl,
        rezervisiTerminPeriodicni : rezervisiTerminPeriodicniImpl,
        ucitajSlike : ucitajSlikeImpl
    }
}());