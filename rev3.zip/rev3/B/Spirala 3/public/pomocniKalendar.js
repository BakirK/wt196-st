 function iscrtajKalendar(){
    Kalendar.iscrtajKalendar(document.getElementsByClassName("kalendar"), new Date().getMonth());
   // redovnaZauzeca = this.zadajPeriodicna();
    //vanrednaZauzeca =this.zadajVanredna();
    //this.ucitajZauzecaPoziv();
    //this.obojiZauzecaPoziv();
}
var kalendar = document.getElementsByClassName("kalendar");
    var redovnaZauzeca = [];
    var vanrednaZauzeca = [];
// dodajem pocetak kraj
    var pocetak;
    var kraj;
    
function mijenjajSljedeci()
{
    var sviMjeseci = ['Januar', 'Februar', 'Mart', 'April', 'Maj', 'Juni', 'Juli', 'August', 'Septembar', 'Oktobar', 'Novembar', 'Decembar'];
    var trenutniMjesec = document.getElementById("nazivMjeseca");
    var i;
    var j;
    var dugmeSljedeci = document.getElementsByClassName("dugmeSljedeci");
    var dugmePrethodni = document.getElementsByClassName("dugmePrethodni");
    // mjeseci od 0 do 11, 0 = januar
    if(trenutniMjesec.innerHTML==="Decembar")
    {
        dugmeSljedeci.disabled = true;
        dugmePrethodni.disabled = false;
    }
    else
    {
        dugmePrethodni.disabled = false;
        for(i=0; i<sviMjeseci.length; i++)
        {
            if(trenutniMjesec.innerHTML===sviMjeseci[i])
            //bilo j = i+2
            j=i+1;
        }
        //bilo [j-1]
        trenutniMjesec.innerHTML = sviMjeseci[j];
        Kalendar.iscrtajKalendar(this.kalendar, j);  
    }
    obojiZauzecaPoziv();
}

function mijenjajPrethodni()
{
    var sviMjeseci = ['Januar', 'Februar', 'Mart', 'April', 'Maj', 'Juni', 'Juli', 'August', 'Septembar', 'Oktobar', 'Novembar', 'Decembar'];
    var trenutniMjesec = document.getElementById("nazivMjeseca");
    var i;
    var j;
    var dugmeSljedeci = document.getElementsByClassName("dugmeSljedeci");
    var dugmePrethodni = document.getElementsByClassName("dugmePrethodni");
    if(trenutniMjesec.innerHTML === "Januar")
    {
        dugmeSljedeci.disabled = false;
        dugmePrethodni.disabled = true;
    }
    else
    {
        dugmeSljedeci.disabled = false;
        for(i=0; i<sviMjeseci.length; i++)
        {
            if(trenutniMjesec.innerHTML===sviMjeseci[i])
            j = i;
        }
        trenutniMjesec.innerHTML = sviMjeseci[j-1];
        Kalendar.iscrtajKalendar(this.kalendar, j-1);
        //ovdje j-1 stavio bilo j
    }
    obojiZauzecaPoziv();
}
var periodicnaZauzeca = [];
var vanredna = [];
var salaEl;
var sala;
/*
function zadajPeriodicna()
{
    periodicnaZauzeca = [
    {
        dan: 0,
        semestar: "zimski",
        pocetak: "12:00",
        kraj: "13:30",
        naziv: "VA1",
        predavac: "Huse"
    },
    {
        dan: 2,
        semestar: "zimski",
        pocetak: "10:00",
        kraj: "11:45",
        naziv: "VA2",
        predavac: "Jurić"
    },
    {
        dan: 1,
        semestar: "zimski",
        pocetak: "09:00",
        kraj: "10:30",
        naziv: "VA1",
        predavac: "Šejla"
    },
    {
        dan: 3,
        semestar: "ljetni",
        pocetak: "15:00",
        kraj: "16:30",
        naziv: "MA",
        predavac: "Ivona"
    } 
    ]
   return periodicnaZauzeca;
}

function zadajVanredna()
{
    vanredna = [
    {
        //datum format "dd.mm.yyyy"
        datum: "12.10.2019",
        //vrijeme format "hh.mm"
        pocetak: "12:00",
        kraj: "13:30",
        naziv: "0-01",
        predavac: "Dinko" 
    },
    {
        datum: "05.08.2019",
        pocetak: "14:00",
        kraj: "16:30",
        naziv: "0-04",
        predavac: "Almasa" 
    },
    {
        datum: "05.08.2019",
        pocetak: "17:00",
        kraj: "19:30",
        naziv: "0-04",
        predavac: "Vedran"
    },
    {
        datum: "26.11.2019",
        pocetak: "10:00",
        kraj: "11:30",
        naziv: "1-01",
        predavac: "Buza" 
    },
    {
        datum: "29.11.2019",
        pocetak: "14:00",
        kraj: "15:30",
        naziv: "1-01",
        predavac: "Nole" 
    },
    {
        datum: "28.11.2019",
        pocetak: "13:00",
        kraj: "14:30",
        naziv: "0-01",
        predavac: "Vensada"
    }
    ]
    return vanredna;
}
*/
function ucitajZauzecaPoziv(){
    
    Kalendar.ucitajPodatke(redovnaZauzeca, vanrednaZauzeca);
    
}
function obojiZauzecaPoziv()
{
    var sviMjeseci = ['Januar', 'Februar', 'Mart', 'April', 'Maj', 'Juni', 'Juli', 'August', 'Septembar', 'Oktobar', 'Novembar', 'Decembar'];
    var trenutniMjesec = document.getElementById("nazivMjeseca");
    var i;
    var j;
    for(i=0; i<sviMjeseci.length; i++)
    {
        if(sviMjeseci[i] === trenutniMjesec.innerHTML)
            j = i;
    }
    pocetak = document.getElementById("pocetak").value;
    kraj = document.getElementById("kraj").value;
    salaEl = document.getElementById("listaSala");
    sala = salaEl.options[salaEl.selectedIndex].value;
    Kalendar.obojiZauzeca(this.kalendar, j, sala, pocetak, kraj);
}

