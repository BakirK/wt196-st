const express = require('express');
const path = require('path');
const app = express();
const fs = require('fs');
//const bodyParser = require('body-parser');
/*app.get('/', function(req, res){
    res.send('Hello world');
});
*/

app.use(express.static(path.join(__dirname, 'public')));

app.use(express.json()); // zbog ove linije koda sam ostario 10 godina za 2 sata

app.get('/', function(req, res){
    res.sendFile('pocetna.html', { root: __dirname + '/public'});
});

app.get('/sale', function(req, res){
    res.sendFile('sale.html', { root: __dirname + '/public'});
});

app.get('/rezervacija', function(req, res){
    res.sendFile('rezervacija.html', { root: __dirname + '/public'});
});

app.get('/unos', function(req, res){
    res.sendFile('unos.html', { root: __dirname + '/public'});
});
//zadatak 1
app.get('/dohvatiPodatke', function(req, res){
    res.sendFile('zauzeca.json', { root: __dirname});
});
//zadatak 2
app.post('/unesiPodatke', function(req, res){
   let dodajUDzejson = req.body;
    let ubaciNovi = {
        datum : dodajUDzejson['datum'],
        pocetak : dodajUDzejson['pocetak'],
        kraj : dodajUDzejson['kraj'],
        naziv : dodajUDzejson['naziv']
    };
    fs.readFile('zauzeca.json', function(err, data){
        let rezultat = JSON.parse(data);
        rezultat.vanredna.push(ubaciNovi);
        let jsone = JSON.stringify(rezultat, null, 2);
        fs.writeFile('zauzeca.json', jsone, function(err){
            if(err) throw err;
            console.log('Uspješno dodano');
        });
    });
    
});

app.post('/unesiPeriodicno', function(req, res){
    let dodajUDzejson = req.body;
    let ubaciNovi = {
        dan : dodajUDzejson['dan'],
        semestar : dodajUDzejson['semestar'],
        pocetak : dodajUDzejson['pocetak'],
        kraj : dodajUDzejson['kraj'],
        naziv : dodajUDzejson['naziv']
    };
    fs.readFile('zauzeca.json', function(err, data){
        let rezultat = JSON.parse(data);
        rezultat.periodicna.push(ubaciNovi);
        let jsone = JSON.stringify(rezultat, null, 2);
        console.log(jsone);
        fs.writeFile('zauzeca.json', jsone, function(err){
            if(err) throw err;
            console.log('Uspješno dodano');
        });
    });
})
//zadatak 3
app.get('/dohvatiSlike', function(req, res){
    var slike = {};
    var i;
   for(i=0; i<10; i++)
    {
        var slika = fs.readFileSync(__dirname + `/public/slikeGalerije/${i+1}.png`)
        slike[`s${i+1}`] = slika;
    }
           res.send(JSON.stringify(slike));
})

app.listen(8080, () => console.log("Server radi na portu 8080"));