const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(express.static(__dirname));

// ZADATAK 1
app.get('/', function (req, res) {
    res.sendFile(__dirname + '/rezervacija.html');
});
app.get('/zauzecaJSON', (req, res) => {
    res.header("Content-Type", 'application/json');
    res.sendFile(path.join(__dirname, 'zauzeca.json'));
});


// ZADATAK 2
app.post('/z2', function (req, res) {
    let tijelo = req.body;

    fs.readFile('zauzeca.json'  , function (err, data) {
        if (err) throw err
        var arrayOfObjects = JSON.parse(data)

        if (tijelo['dan'] != undefined) {
            arrayOfObjects.objekat.periodicna.push({
                dan: tijelo['dan'],
                semestar: tijelo['semestar'],
                pocetak: tijelo['pocetak'],
                kraj: tijelo['kraj'],
                naziv: tijelo['naziv'],
                predavac: tijelo['predavac']
            })
        } else {
            arrayOfObjects.objekat.vanredna.push({
                datum: tijelo['datum'],
                pocetak: tijelo['pocetak'],
                kraj: tijelo['kraj'],
                naziv: tijelo['naziv'],
                predavac: tijelo['predavac']
            })
        }


        fs.writeFile('zauzeca.json', JSON.stringify(arrayOfObjects, null , 2), 'utf-8', function (err) {
            if (err) throw err
            console.log('Done!')

            if (tijelo['dan'] != undefined) {
                res.json({
                    dan: tijelo['dan'],
                    semestar: tijelo['semestar'],
                    pocetak: tijelo['pocetak'],
                    kraj: tijelo['kraj'],
                    naziv: tijelo['naziv'],
                    predavac: tijelo['predavac']
                });
            } else {
                res.json({
                    datum: tijelo['datum'],
                    pocetak: tijelo['pocetak'],
                    kraj: tijelo['kraj'],
                    naziv: tijelo['naziv'],
                    predavac: tijelo['predavac']
                });
            }
        })
    })
});


// ZADATAK 3
var imageDir = __dirname + "/img/";
app.get("/img/:id", function (request, response) {
    var path = imageDir + request.params.id + '.jpg';
    console.log("fetching image: ", path);
    response.sendFile(path);
});


app.listen(8080, () => {
    console.log('Server radi...');
});