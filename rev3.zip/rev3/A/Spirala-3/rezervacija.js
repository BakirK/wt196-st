// poziv za zadatak 1
Pozivi.dajPodatke();

// Kod za 2. zadatak se nalazi u Pozivi.js i kalendar.js