var globDatum;
var redovnaZauzeca;
var vanrednaZauzeca;




let Kalendar = (function() {



    this.globDatum = new Date();
    this.redovnaZauzeca;
    this.vanrednaZauzeca;


    function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj) {

        var elementiOvogaKalendara = kalendarRef[0].children;
        var elementiSedmice1 = elementiOvogaKalendara[1].children;
        var elementiSedmice2 = elementiOvogaKalendara[2].children;
        var elementiSedmice3 = elementiOvogaKalendara[3].children;
        var elementiSedmice4 = elementiOvogaKalendara[4].children;
        var elementiSedmice5 = elementiOvogaKalendara[5].children;
        var elementiSedmice6 = elementiOvogaKalendara[6].children;

        if (redovnaZauzeca == null && vanrednaZauzeca == null) return;
        for (var i = 0; i < redovnaZauzeca.length; i++) {

            if (redovnaZauzeca[i].semestar == "zimski") {
                if ((mjesec > 9 && mjesec <= 12) || mjesec == 1) {
                    document.getElementsByClassName("dropdown")[0].options[0].innerHTML = redovnaZauzeca[i].naziv;
                    document.getElementsByName("pocetak")[0].value = redovnaZauzeca[i].pocetak;
                    document.getElementsByName("kraj")[0].value = redovnaZauzeca[i].kraj;
                    document.getElementsByName("periodicna")[0].checked = true;


                    for (var sedmica = 1; sedmica < 7; sedmica++) {
                        if (elementiOvogaKalendara[sedmica].children[redovnaZauzeca[i].dan].innerText == "") continue;


                        elementiOvogaKalendara[sedmica].children[redovnaZauzeca[i].dan].children[0].style.border = "2px solid red";
                    }




                }
            }



            if (redovnaZauzeca[i].semestar == "ljetni") {
                if ((mjesec > 1 && mjesec <= 6)) {
                    document.getElementsByClassName("dropdown")[0].options[0].innerHTML = redovnaZauzeca[i].naziv;
                    document.getElementsByName("pocetak")[0].value = redovnaZauzeca[i].pocetak;
                    document.getElementsByName("kraj")[0].value = redovnaZauzeca[i].kraj;
                    document.getElementsByName("periodicna")[0].checked = true;

                    for (var j = 1; j < 6; j++) {


                        for (var sedmica = 1; sedmica < 7; sedmica++) {
                            if (elementiOvogaKalendara[sedmica].children[redovnaZauzeca[i].dan].innerText == "") continue;


                            elementiOvogaKalendara[sedmica].children[redovnaZauzeca[i].dan].children[0].style.border = "2px solid red";
                        }


                    }

                }
            }



        }


        for (var i = 0; i < vanrednaZauzeca.length; i++) {




            var noviString = vanrednaZauzeca[i].datum.replace(/\./g, "/");
            /*      var mojDatum = new Date(noviString);
                 var tacanDan = mojDatum.getDate();
                 var tacanDanBroj = parseInt(tacanDan); */
            var tacanDan = noviString.substring(0, 2);
            var tacanDanBroj = parseInt(tacanDan);

            var mjesecTrenutni = noviString.substring(3, 5)
            var mjesecBroj = parseInt(mjesecTrenutni);
            console.log(mjesecBroj);
            var mjesecStr = "Januar";
            if (mjesecBroj == 2) mjesecStr = "Februar";
            if (mjesecBroj == 3) mjesecStr = "Mart";
            if (mjesecBroj == 4) mjesecStr = "April";
            if (mjesecBroj == 5) mjesecStr = "Maj";
            if (mjesecBroj == 6) mjesecStr = "Jun";
            if (mjesecBroj == 7) mjesecStr = "Jul";
            if (mjesecBroj == 8) mjesecStr = "August";
            if (mjesecBroj == 9) mjesecStr = "Septembar";
            if (mjesecBroj == 10) mjesecStr = "Oktobar";
            if (mjesecBroj == 11) mjesecStr = "Novembar";
            if (mjesecBroj == 12) mjesecStr = "Decembar";


            var test = false;

            document.getElementsByClassName("dropdown")[0].options[0].innerHTML = vanrednaZauzeca[i].naziv;
            document.getElementsByName("pocetak")[0].value = vanrednaZauzeca[i].pocetak;
            document.getElementsByName("kraj")[0].value = vanrednaZauzeca[i].kraj;
            document.getElementsByName("periodicna")[0].checked = true;

            for (var sedmica = 1; sedmica < 7; sedmica++) {

                if (document.getElementById("nazivMjeseca").innerText == mjesecStr) {
                    for (var br = 0; br < 7; br++) {
                        if (document.getElementById("nazivMjeseca").innerText == mjesecStr &&
                            elementiOvogaKalendara[sedmica].children[br].innerText == tacanDanBroj) {
                            console.log(mjesecStr);
                            console.log(document.getElementById("nazivMjeseca").innerText);
                            elementiOvogaKalendara[sedmica].children[br].children[0].style.border = "2px solid red";
                            test = true;
                        }
                        if (test == true) break;
                        // elementiOvogaKalendara[sedmica].children[redovnaZauzeca[i].dan].children[0].style.border = "2px solid red";
                    }
                    if (test == true) break;
                }
                //    elementiOvogaKalendara[sedmica].children[tacanDanBroj].style.border = "2px solid red";
            }

        }






    }


    function ucitajPodatkeImpl(periodicna, vanredna) {
        redovnaZauzeca = periodicna;
        vanrednaZauzeca = vanredna;
    }


    function iscrtajKalendarImpl(kalendarRef, mjesec) {
        var elementiOvogaKalendara = kalendarRef[0].children;
        var elementiSedmice1 = elementiOvogaKalendara[1].children;
        var elementiSedmice2 = elementiOvogaKalendara[2].children;
        var elementiSedmice3 = elementiOvogaKalendara[3].children;
        var elementiSedmice4 = elementiOvogaKalendara[4].children;
        var elementiSedmice5 = elementiOvogaKalendara[5].children;
        var elementiSedmice6 = elementiOvogaKalendara[6].children;
        var names = document.querySelectorAll('li hr');
        //var blablabla = elementiOvogaKalendara[1].children[1].children[0];
        for (var jk = 1; jk < elementiOvogaKalendara.length; jk++) {
            for (var kl = 0; kl < 7; kl++) {

                elementiOvogaKalendara[jk].children[kl].innerHTML = "";
                var hrElement = document.createElement("hr");
                elementiOvogaKalendara[jk].children[kl].appendChild(hrElement);
                elementiOvogaKalendara[jk].children[kl].children[0].style.border = "2px solid royalblue";

            }
        }

        for (var i = 0; i < 49; i++) {
            names[i].style.border = "2px solid royalblue";
        }

        if (mjesec == 0) {
            var brojac = 1;
            document.getElementById("nazivMjeseca").innerHTML = "Januar";
            globDatum.setMonth(mjesec);
            for (var jka = 1; jka < elementiOvogaKalendara.length; jka++) {
                for (var kla = 0; kla < 7; kla++) {
                    if (jka == 1 && kla == 0) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    } else if (brojac <= 31) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = brojac;
                        brojac++;
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "2px solid royalblue";
                    } else if (brojac >= 32) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    }
                }
            }

        } else if (mjesec == 1) {
            document.getElementById("nazivMjeseca").innerHTML = "Februar";
            globDatum.setMonth(mjesec);
            var brojac = 1;

            for (var jka = 1; jka < elementiOvogaKalendara.length; jka++) {
                for (var kla = 0; kla < 7; kla++) {
                    if (jka == 1 && kla <= 3) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    } else if (brojac <= 28) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = brojac;
                        brojac++;
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "2px solid royalblue";
                    } else if (brojac >= 29) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    }
                }
            }

        } else if (mjesec == 2) {
            document.getElementById("nazivMjeseca").innerHTML = "Mart";
            globDatum.setMonth(mjesec);
            var brojac = 1;

            for (var jka = 1; jka < elementiOvogaKalendara.length; jka++) {
                for (var kla = 0; kla < 7; kla++) {
                    if (jka == 1 && kla <= 3) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    } else if (brojac <= 31) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = brojac;
                        brojac++;
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "2px solid royalblue";
                    } else if (brojac >= 31) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    }
                }
            }

        } else if (mjesec == 3) {
            document.getElementById("nazivMjeseca").innerHTML = "April";
            globDatum.setMonth(mjesec);
            var brojac = 1;

            for (var jka = 1; jka < elementiOvogaKalendara.length; jka++) {
                for (var kla = 0; kla < 7; kla++) {
                    if (brojac <= 30) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = brojac;
                        brojac++;
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "2px solid royalblue";
                    } else if (brojac >= 30) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    }
                }
            }

        } else if (mjesec == 4) {
            document.getElementById("nazivMjeseca").innerHTML = "Maj";
            var brojac = 1;
            globDatum.setMonth(mjesec);
            for (var jka = 1; jka < elementiOvogaKalendara.length; jka++) {
                for (var kla = 0; kla < 7; kla++) {
                    if (jka == 1 && kla <= 1) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    } else if (brojac <= 31) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = brojac;
                        brojac++;
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "2px solid royalblue";
                    } else if (brojac >= 31) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    }
                }
            }

        } else if (mjesec == 5) {
            document.getElementById("nazivMjeseca").innerHTML = "Juni";
            var brojac = 1;
            globDatum.setMonth(mjesec);
            for (var jka = 1; jka < elementiOvogaKalendara.length; jka++) {
                for (var kla = 0; kla < 7; kla++) {
                    if (jka == 1 && kla <= 4) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    } else if (brojac <= 30) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = brojac;
                        brojac++;
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "2px solid royalblue";
                    } else if (brojac >= 30) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    }
                }
            }


        } else if (mjesec == 6) {
            document.getElementById("nazivMjeseca").innerHTML = "Juli";
            var brojac = 1;
            globDatum.setMonth(mjesec);
            for (var jka = 1; jka < elementiOvogaKalendara.length; jka++) {
                for (var kla = 0; kla < 7; kla++) {
                    if (brojac <= 31) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = brojac;
                        brojac++;
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "2px solid royalblue";
                    } else if (brojac >= 31) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    }
                }
            }


        } else if (mjesec == 7) {
            document.getElementById("nazivMjeseca").innerHTML = "August";
            var brojac = 1;
            globDatum.setMonth(mjesec);
            for (var jka = 1; jka < elementiOvogaKalendara.length; jka++) {
                for (var kla = 0; kla < 7; kla++) {
                    if (jka == 1 && kla <= 2) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    } else if (brojac <= 31) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = brojac;
                        brojac++;
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "2px solid royalblue";
                    } else if (brojac >= 31) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    }
                }
            }


        } else if (mjesec == 8) {
            document.getElementById("nazivMjeseca").innerHTML = "Septembar";

            var brojac = 1;
            globDatum.setMonth(mjesec);
            for (var jka = 1; jka < elementiOvogaKalendara.length; jka++) {
                for (var kla = 0; kla < 7; kla++) {
                    if (jka == 1 && kla <= 5) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    } else if (brojac <= 30) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = brojac;
                        brojac++;
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "2px solid royalblue";
                    } else if (brojac >= 30) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    }
                }
            }

        } else if (mjesec == 9) {
            document.getElementById("nazivMjeseca").innerHTML = "Oktobar";
            var brojac = 1;
            globDatum.setMonth(mjesec);
            for (var jka = 1; jka < elementiOvogaKalendara.length; jka++) {
                for (var kla = 0; kla < 7; kla++) {
                    if (jka == 1 && kla <= 0) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");

                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    } else if (brojac <= 31) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = brojac;
                        brojac++;
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "2px solid royalblue";
                    } else if (brojac >= 31) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    }
                }
            }


        } else if (mjesec == 10) {
            document.getElementById("nazivMjeseca").innerHTML = "Novembar";
            var brojac = 1;
            globDatum.setMonth(mjesec);
            for (var jka = 1; jka < elementiOvogaKalendara.length; jka++) {
                for (var kla = 0; kla < 7; kla++) {
                    if (jka == 1 && kla <= 3) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    } else if (brojac <= 30) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = brojac;
                        brojac++;
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "2px solid royalblue";
                    } else if (brojac >= 30) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    }
                }
            }


        } else if (mjesec == 11) {
            document.getElementById("nazivMjeseca").innerHTML = "Decembar";
            var brojac = 1;
            globDatum.setMonth(mjesec);
            for (var jka = 1; jka < elementiOvogaKalendara.length; jka++) {
                for (var kla = 0; kla < 7; kla++) {
                    if (jka == 1 && kla <= 5) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    } else if (brojac <= 31) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = brojac;
                        brojac++;
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "2px solid royalblue";
                    } else if (brojac >= 31) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    }
                }
            }

        } else if (mjesec == 12) {
            document.getElementById("dugme2").disabled = true;
            var brojac = 1;

            for (var jka = 1; jka < elementiOvogaKalendara.length; jka++) {
                for (var kla = 0; kla < 7; kla++) {
                    if (jka == 1 && kla <= 5) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    } else if (brojac <= 31) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = brojac;
                        brojac++;
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "2px solid royalblue";
                    } else if (brojac >= 31) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    }
                }
            }
        } else if (mjesec == -1) {
            document.getElementById("dugme1").disabled = true;
            var brojac = 1;


            for (var jka = 1; jka < elementiOvogaKalendara.length; jka++) {
                for (var kla = 0; kla < 7; kla++) {
                    if (jka == 1 && kla == 0) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    } else if (brojac <= 31) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = brojac;
                        brojac++;
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "2px solid royalblue";
                    } else if (brojac >= 32) {
                        elementiOvogaKalendara[jka].children[kla].innerHTML = "";
                        var hrElement = document.createElement("hr");
                        elementiOvogaKalendara[jka].children[kla].appendChild(hrElement);
                        elementiOvogaKalendara[jka].children[kla].children[0].style.border = "none";
                    }
                }
            }
        }
    }

    return {
        obojiZauzeca: obojiZauzecaImpl,
        ucitajPodatke: ucitajPodatkeImpl,
        iscrtajKalendar: iscrtajKalendarImpl
    }
}());