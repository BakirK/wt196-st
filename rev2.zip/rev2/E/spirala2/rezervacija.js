let Kalendar = (function () {
    
    function iscrtajKalendarImpl(){
    
    var date = new Date();
    var firstDay = new Date(date.getFullYear(), 10, 1).getDay();
    var lastDay = new Date(date.getFullYear(), 11, 0).getDate();
    
    for (var i = 1; i < firstDay; i++) {
        var gridItem = document.createElement("div");
        gridItem.classList.add("grid-item");
        calendarContainer.appendChild(gridItem);
    }

    for (var i = 1; i <= lastDay; i++) {
        var gridItem = document.createElement("div");
        gridItem.classList.add("grid-item");
        gridItem.classList.add("grid-a");

        var gridB = document.createElement("div");
        gridB.classList.add("grid-b");
        var date = document.createTextNode(i+"");
        gridB.appendChild(date);

        var gridB2 = document.createElement("div");
        gridB2.classList.add("grid-b");
        gridB2.classList.add("slobodna");
        gridB2.setAttribute("id", "dan_"+i);


        gridItem.appendChild(gridB);
        gridItem.appendChild(gridB2);

        calendarContainer.appendChild(gridItem);
    }
    
} 

function ucitajPodatkeImpl(periodicni, vanredni) {
    var zimski = [9, 10, 11, 0];
    var ljetni = [1, 2, 3, 4, 5];
    for(var i = 0; i < zimski.length;i++){
        for(var j = 0; j<periodicni.length;j++) {
            if(periodicni[j].semestar == "zimski") {
                var dani = periodicniDaniUMjesecu(periodicni[j].dan+1, zimski[i]);
                dani.forEach(dan => podaci.push(dan));
            }
        }
    }

    for(var i = 0; i < ljetni.length;i++){
        for(var j = 0; j<periodicni.length;j++) {
            if(periodicni[j].semestar == "ljetni") {
                var dani = periodicniDaniUMjesecu(periodicni[j].dan+1, ljetni[i]);
                dani.forEach(dan => podaci.push(dan));
            }
        }
    }

    for (var i = 0; i < vanredni.length; i++) {
        var date = vanredni[i].datum.split(".");
        podaci.push(new Date(date[2], date[1] - 1, date[0]));
    }
}

function obojiZauzecaImpl(calendar, month) {
    for(var i = 0; i<podaci.length;i++){
        if(month === podaci[i].getMonth()) {
            var element = document.getElementById("dan_"+podaci[i].getDate());
            element.classList.remove("slobodna");
            element.classList.add("zauzeta");
        } 
    }
}

function periodicniDaniUMjesecu(dan, mjesec) {
    var d = new Date(),
        month = mjesec,
        days = [];

    d.setDate(1);
    d.setMonth(mjesec);
    // Get the first day in the month
    while (d.getDay() !== dan) {
        d.setDate(d.getDate() + 1);
    }
    // Get all the other days in the month
    while (d.getMonth() === month) {
        days.push(new Date(d.getTime()));
        d.setDate(d.getDate() + 7);
    }
    return days;
}
return {
    obojiZauzeca: obojiZauzecaImpl,
    ucitajPodatke: ucitajPodatkeImpl,
    iscrtajKalendar: iscrtajKalendarImpl
    }
} ());